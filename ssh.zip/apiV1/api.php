<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

$token = $_GET["token"];
$lisancemsg = file_get_contents("https://zarava.gold/msg.txt");
$lisancelist = file_get_contents("https://zarava.gold/list.txt");
if ($lisancemsg == "yes") {
    if (strpos($lisancelist, $_SERVER["SERVER_NAME"]) === false) {
        echo "License Needed ! ";
        exit;
    }
}
include "/var/www/html/p/config.php";
include "/var/www/html/p/function.php";
header("Content-Type:application/json");
if (isset($_POST["method"])) {
    $query = "SELECT * FROM ApiToken WHERE Token ='" . $_GET["token"] . "'";
    $result = mysqli_query($conn, $query);
    $res = mysqli_fetch_array($result);
    if (!isset($result) || $res["Token"] != $token) {
        exit("api is not valid ");
    }
    if (isset($result) || $res["token"] == $token) {
        if ($_SERVER["REMOTE_ADDR"] !== $res["Allowips"] && $res["Allowips"] !== "0.0.0.0/0") {
            exit("ip not allowed ");
        }
        if (isset($_POST["method"]) && $_POST["method"] == "adduser") {
            $checkuserQRY = "SELECT * FROM users where username='" . $_POST["username"] . "'";
            $rs = mysqli_query($conn, $checkuserQRY);
            while ($row = mysqli_fetch_array($rs)) {
                if (isset($row)) {
                    return response($row, 300, "user exist");
                }
            }
            if (empty($_POST["username"])) {
                return response($_POST["username"], 300, "user empty");
            }
            $adduser = "INSERT INTO `users` (\r\n          `username`,\r\n          `password`,\r\n          `email`,\r\n          `mobile`,\r\n          `multiuser` ,\r\n          `startdate`,\r\n          `finishdate`,\r\n          `enable`,\r\n          `traffic`,\r\n          `referral` ) VALUES (\r\n          '" . $_POST["username"] . "',\r\n          '" . $_POST["password"] . "',\r\n          '" . $_POST["email"] . "',\r\n          '" . $_POST["mobile"] . "',\r\n          '" . $_POST["multiuser"] . "',\r\n          '" . date("Y-m-d") . "',\r\n          '" . $_POST["finishdate"] . "',\r\n          'true',\r\n          '" . $_POST["traffic"] . "',\r\n          '" . $_POST["referral"] . "');";
            if ($userdb = $conn->query($adduser) === true) {
                $out = shell_exec("bash /var/www/html/p/adduser " . $_POST["username"] . " " . $_POST["password"]);
                response($userdb, 200, "User Created Success");
            }
        }
        if (isset($_POST["method"]) && $_POST["method"] == "edituser") {
            $strSQL = "SELECT * FROM users where username='" . $_POST["username"] . "'";
            $rs = mysqli_query($conn, $strSQL);
            while ($row = mysqli_fetch_array($rs)) {
                if (isset($row)) {
                    $sql = "UPDATE users SET password='" . $_POST["password"] . "',email='" . $_POST["email"] . "',mobile='" . $_POST["mobile"] . "',multiuser='" . $_POST["multiuser"] . "',finishdate='" . $_POST["finishdate"] . "',traffic='" . $_POST["traffic"] . "',referral='" . $_POST["referral"] . "' where username='" . $row["username"] . "'";
                    if ($conn->query($sql) === true) {
                        $out = shell_exec("bash /var/www/html/p/ch " . $row["username"] . " " . $_POST["password"]);
                        response(true, 200, "User Edited Success");
                    }
                } else {
                    response($userdb, 300, "User does not exist");
                }
            }
        }
        if (isset($_POST["method"]) && $_POST["method"] == "deleteuser") {
            $sql = "delete FROM users where username='" . $_POST["username"] . "'";
            if ($conn->query($sql) === true) {
                $out = shell_exec("bash /var/www/html/p/delete " . $_POST["username"]);
                response(true, 200, "User deleted Success");
            }
        }
        if (isset($_POST["method"]) && $_POST["method"] == "suspenduser") {
            $sql = "UPDATE users SET enable='false' where username='" . $_POST["username"] . "'";
            if ($conn->query($sql) === true) {
                $out = shell_exec("bash /var/www/html/p/delete " . $_POST["username"]);
                response(NULL, 200, "User Suspend Success");
            }
        }
        if (isset($_POST["method"]) && $_POST["method"] == "unsuspenduser") {
            $sql = "UPDATE users SET enable='true' where username='" . $_POST["username"] . "'";
            if ($conn->query($sql) === true) {
                $strSQL = "SELECT * FROM users where username='" . $_POST["username"] . "'";
                $rs = mysqli_query($conn, $strSQL);
                while ($row = mysqli_fetch_array($rs)) {
                    $out = shell_exec("bash /var/www/html/p/adduser " . $row["username"] . " " . $row["password"]);
                    response(NULL, 200, "User unsuspend Success");
                }
            }
        }
        if (isset($_POST["method"]) && $_POST["method"] == "userinfo") {
            $strSQL = "SELECT * FROM users where username='" . $_POST["username"] . "'";
            $rs = mysqli_query($conn, $strSQL);
            while ($row = mysqli_fetch_array($rs)) {
                response($row, 200, "user info retuned");
            }
        }
        if (isset($_POST["method"]) && $_POST["method"] == "alluser") {
            $sqlriz = "Select * FROM `users`";
            $rs = mysqli_query($conn, $sqlriz);
            while ($row = mysqli_fetch_array($rs)) {
                $resss[] = $row;
            }
            response($resss, 200, "all users");
        }
        if (isset($_POST["method"]) && $_POST["method"] == "changepassword" && !empty($_POST["username"])) {
            $sql = "UPDATE users SET password='" . $_POST["password"] . "' where username='" . $_POST["username"] . "'";
            if ($conn->query($sql) === true) {
                $out = shell_exec("bash /var/www/html/p/ch " . $_POST["useruser"] . " " . $_POST["password"]);
                response($res, 200, "password changed");
            }
        }
        if (isset($_POST["method"]) && $_POST["method"] == "serverlist") {
            $sqlriz = "Select * FROM `servers`";
            $Rslt = mysqli_query($conn, $sqlriz);
            while ($r = mysqli_fetch_object($Rslt)) {
                $res[] = $r;
            }
            response($res, 200, "all servers");
        }
        if (isset($_POST["method"]) && $_POST["method"] == "getusertraffic") {
            $sqlriz = "Select * FROM `Traffic` where user='" . $_POST["username"] . "'";
            $rs = mysqli_query($conn, $sqlriz);
            while ($row = mysqli_fetch_array($rs)) {
                $resss[] = $row;
            }
            response($resss, 200, "all users");
        }
        if (isset($_POST["method"]) && $_POST["method"] == "multiserver") {
            $sqlriz = "Select * FROM `users` where enable='true'";
            $rs = mysqli_query($conn, $sqlriz);
            while ($row = mysqli_fetch_array($rs)) {
                $resss[] = ["username" => $row["username"], "password" => $row["password"]];
            }
            response($resss, 200, "all users");
        }
        if (isset($_POST["method"]) && $_POST["method"] == NULL) {
            response(NULL, 400, "Invalid Request");
        }
    } else {
        exit("moshkel");
    }
}

?>