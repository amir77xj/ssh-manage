<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

include "config.php";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    exit("Connection failed: " . $conn->connect_error);
}
if (isset($_POST["query"])) {
    $query = "SELECT * FROM users WHERE username LIKE '" . $_POST["query"] . "%' LIMIT 10";
    $result = mysqli_query($conn, $query);
    if (0 < mysqli_num_rows($result)) {
        while ($res = mysqli_fetch_array($result)) {
            echo "<a href='/p/newuser.php?edituser=" . $res["username"] . "' ><div class='alert mt-3 text-center' role='alert' style='border: 1px solid #dddddd;background-color: #e9ffe9;margin-bottom: 1px !important;'>\r\n         " . $res["username"] . "\r\n      </div></a>\r\n\t\t";
        }
    } else {
        echo "\r\n      <div class='alert alert-danger mt-3 text-center' role='alert'>\r\n          نام کاربری یافت نشد .\r\n      </div>\r\n      ";
    }
}

?>