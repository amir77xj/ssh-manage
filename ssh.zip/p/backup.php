<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

include "header.php";
include "menu.php";
$date = date("Y-m-d-his");
if (!empty($_GET["backupuser"])) {
    $output = shell_exec("mysqldump -u " . $username . " --password=" . $password . " ShaHaN users > /var/www/html/p/backup/" . $date . ".sql");
    $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nبکاپ با موفقیت انجام شد \r\n</div>";
}
if (!empty($_GET["delete"])) {
    $output = shell_exec("rm -fr /var/www/html/p/backup/" . $_GET["delete"]);
    $msg = "<div class=\"alert alert-danger alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nفایل حذف شد \r\n</div>";
}
echo "                <div class=\"row\">\r\n                <div class=\"col-md-12\">\r\n                    <div class=\"panel\">\r\n                        <div class=\"panel-heading\" style=\"display: inline-block;\">بکاپ کاربران</div>\r\n\t\t\t\t\t\t";
echo $msg;
echo "\t\t\t\t\t\t<div class=\"table-responsive\">\r\n\t\t\t\t\t\t<a href=\"backup.php?backupuser=";
echo $date;
echo "\" class=\"btn btn-primary m-t-10 btn-rounded\" style=\"margin-right: 40px !important;\">بکاپ کاربران</a>\r\n\t\t\t\t\t\t<table class=\"table table-hover manage-u-table\">\r\n                                <thead>\r\n\t\t\t\t\t\t\t\t\t<tr>\r\n                                        <th width=\"70\" class=\"text-center\">#</th>\r\n                                        <th>تاریخ بکاپ</th>\r\n                                        <th></th>\r\n                                        <th></th>\r\n                                        <th></th>\r\n                                        <th width=\"250\"></th>\r\n                                        <th width=\"300\">دریافت</th>\r\n                                    </tr>\r\n                                </thead>\r\n                                <tbody>\r\n\t\t\t\t\t\t\t\t";
$m = 1;
$output = shell_exec("ls /var/www/html/p/backup");
$backuplist = preg_split("/\r\n|\n|\r/", $output);
foreach ($backuplist as $backup) {
    if (!empty($backup)) {
        echo "\r\n\t\t\t\t\t\t\t\t\t\t<tr>\r\n\t\t\t\t\t\t\t\t\t\t\t<td class=\"text-center\">" . $m . "</td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td><span class=\"font-medium\">" . $backup . "</span></td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td></td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td></td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td></td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td></td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td><a href=\"/p/backup/" . $backup . "\"><span class=\"label label-success\">Download</span></a>\r\n\t\t\t\t\t\t\t\t\t\t\t<a href=\"backup.php?delete=" . $backup . "\"><span class=\"label label-danger\">Remove</span></a></td>\r\n\t\t\t\t\t\t\t\t\t\t</tr>";
    }
    $m++;
}
echo "\t\t\t\t\t\t\t\t</tbody>\r\n                        </table>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n\t\t\t</div>\r\n            ";
include "footer.php";

?>