<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

include "header.php";
if ($_POST["passtype"] == "number") {
    $alphabet = "1234567890";
}
if ($_POST["passtype"] == "alpha") {
    $alphabet = "abcdefghijklmnopqrstuvwxyz1234567890";
}
$startword = $_POST["startword"];
if (isset($_POST["submitbulkuser"]) && !empty($_POST["count"]) && $_POST["count"] !== "0" && !empty($_POST["numberstart"])) {
    $password = $_POST["password"];
    $m = $_POST["numberstart"];
    $count = $_POST["count"];
    for ($i = 0; $i < $_POST["count"]; $i++) {
        if ($m < $m + $count) {
            $userlist[] = $startword . $m;
            $m++;
        }
    }
    foreach ($userlist as $user) {
        if (empty($password) || $password !== $_POST["password"]) {
            $password = randomPassword($_POST["passwordnumber"], $alphabet);
        }
        if ($_POST["trafficsize"] == "gb") {
            $traffic = $_POST["traffic"] * 1024;
        } else {
            $traffic = $_POST["traffic"];
        }
        if ($_SESSION["username"] !== $username && file_exists("/var/www/html/p/admin.php")) {
            $multi = "1";
            $traffic = "0";
            $account = 1;
            if ($_POST["accountmonth"] == "1m") {
                $account = 1;
            }
            if ($_POST["accountmonth"] == "2m") {
                $account = 2;
            }
            if ($_POST["accountmonth"] == "3m") {
                $account = 3;
            }
            $expdate = date("Y-m-d", strtotime(date("Y-m-d", strtotime(date("Y-m-d"))) . "+" . $account . " month"));
            $newcredit = $credit - $account * $_POST["count"];
            $referal = $_SESSION["username"];
        } else {
            $referal = $_POST["referral"];
            $multi = $_POST["multiuser"];
            $expdate = $_POST["finishdate"];
        }
        $adduser = "INSERT INTO `users` (\r\n `username`,\r\n `password`,\r\n `multiuser` ,\r\n `finishdate`,\r\n `traffic`,\r\n  `referral`,\r\n `enable`) VALUES (\r\n '" . $user . "',\r\n '" . $password . "',\r\n '" . $multi . "',\r\n '" . $expdate . "',\r\n '" . $traffic . "',\r\n '" . $referal . "',\r\n 'true');";
        if ($conn->query($adduser) === true) {
        }
        $out = shell_exec("bash adduser " . $user . " " . $password);
        $sql = "UPDATE setting SET credit='" . $newcredit . "'  where adminuser='" . $_SESSION["username"] . "'";
        if ($conn->query($sql) === true) {
        }
        $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nلیست کاربران ایجاد شد .\r\n</div>";
    }
}
include "menu.php";
echo "                <div class=\"row\">\r\n                <div class=\"col-md-12\">\r\n                    <div class=\"panel\">\r\n                        <div class=\"panel-heading\" style=\"display: inline-block;\">ثبت کاربر تعدادی</div>\r\n\t\t\t\t\t\t";
echo $msg;
echo "\t\t\t\t\t\t<div class=\"table-responsive\" >\r\n\t\t\t\t\t\t<form action=\"bulkuser.php\" method=\"post\">\r\n                        <div class=\"col-md-6\">\r\n\t\t\t\t\t\t\t<div class=\"white-box\">\r\n\t\t\t\t\t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"col-sm-12 col-xs-12\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputEmail1\">تعداد ساخت یوزر : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"count\" type=\"number\" class=\"form-control\" id=\"exampleInputEmail1\" value=\"2\">\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputEmail1\">کلمه شروع : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"startword\" type=\"text\" class=\"form-control\" id=\"exampleInputEmail1\" value=\"user\">\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputEmail1\">عدد شروع : ( مثال : User1000 )</label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"numberstart\" type=\"number\" class=\"form-control\" id=\"exampleInputEmail1\" value=\"1000\">\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\" style=\"display: block;\">پسورد ( در صورت ثابت بودن ) - در صورت راندوم بودن پسورد فیلد زیر را خالی بزارید</label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"password\" type=\"text\" class=\"form-control\" id=\"exampleInputPassword1\" >\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<p>نوع ترکیب پسورد راندوم را انتخاب کنید : </p>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"radio radio-success\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"passtype\" id=\"radio4\" value=\"number\" checked>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"radio4\">ترکیب اعداد</label>\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"radio radio-success\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"passtype\" id=\"radio6\" value=\"alpha\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"radio6\">ترکیب حروف و اعداد</label>\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<br>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\" style=\"display: block;\">تعداد حروف پسورد : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"passwordnumber\" type=\"number\" class=\"form-control\" id=\"exampleInputPassword1\" value=\"8\">\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<div class=\"col-md-6\">\r\n\t\t\t\t\t\t\t<div class=\"white-box\">\r\n\t\t\t\t\t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"col-sm-12 col-xs-12\">\r\n\t\t\t\t\t\t\t\t\t\t\t";
if (!($_SESSION["username"] !== $username && file_exists("/var/www/html/p/admin.php"))) {
    echo "\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">کاربر همزمان : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"multiuser\" type=\"text\" class=\"form-control\" id=\"exampleInputPassword1\" value=\"1\">\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">ترافیک : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"traffic\" type=\"text\" class=\"form-control\" id=\"exampleInputPassword1\" value=\"0\">\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"radio radio-success\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"trafficsize\" id=\"radio1\" value=\"mb\" >\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"radio1\"> مگابایت </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"trafficsize\" id=\"radio2\" value=\"gb\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"radio2\" style=\"margin-right: 20px;\"> گیگابایت </label>\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t";
if ($_SESSION["username"] !== $username && file_exists("/var/www/html/p/admin.php")) {
    echo "<div class=\"radio radio-success\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"accountmonth\" id=\"radio11\" value=\"1m\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"radio11\" style=\"margin-right: 20px;\"> یکماهه </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"accountmonth\" id=\"radio12\" value=\"2m\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"radio12\" style=\"margin-right: 20px;\"> دوماهه </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"accountmonth\" id=\"radio13\" value=\"3m\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"radio13\" style=\"margin-right: 20px;\"> سه ماهه </label>\r\n\t\t\t\t\t\t\t\t\t\t\t</div>";
} else {
    echo "\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">تاریخ انقضا : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"finishdate\" type=\"date\" class=\"form-control\" id=\"exampleInputPassword1\" placeholder=\"Expire Date\">\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t";
}
echo "\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">معرف : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"referral\" type=\"text\" class=\"form-control\" id=\"exampleInputPassword1\" >\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\" style=\"float: left;\">\r\n\t\t\t\t\t\t\t\t\t\t\t<button name=\"submitbulkuser\" type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\" value=\"submitnewuser\" >ثبت</button>\r\n\t\t\t\t\t\t\t\t\t\t\t<a href=\"index.php\" class=\"btn btn-inverse waves-effect waves-light\">انصراف</a>\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t</form>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n\t\t\t</div>\r\n            ";
include "footer.php";

?>