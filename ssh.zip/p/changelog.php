<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

include "header.php";
include "menu.php";
$msg = file_get_contents("https://konusanlar.tk/changelog.txt");
echo " <div class=\"row\">\r\n                <div class=\"col-md-12\">\r\n                    <div class=\"panel\">\r\n                        <div class=\"panel-heading\" style=\"display: inline-block;\">تغییرات آپدیت</div>\r\n\t\t\t\t\t\t<div class=\"table-responsive\" style=\"padding-left: 40px !important;direction: ltr;\">\r\n\t\t\t\t\t\t<p>";
echo $msg;
echo " </p>\r\n\t\t\t\t\t\t</div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n\t\t\t</div>\r\n";
include "footer.php";

?>