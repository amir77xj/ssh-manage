<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

include "config.php";
$strSQL = "SELECT * FROM users";
$rs = mysqli_query($conn, $strSQL);
while ($row = mysqli_fetch_array($rs)) {
    if (!empty($row["finishdate"])) {
        $expiredate = strtotime(date("Y-m-d", strtotime($row["finishdate"])));
        if ($expiredate < strtotime(date("Y-m-d")) || $expiredate == strtotime(date("Y-m-d"))) {
            $sql = "UPDATE users SET enable='expired' where username='" . $row["username"] . "'";
            if ($conn->query($sql) === true) {
            }
            $out = shell_exec("bash /var/www/html/p/delete " . $row["username"]);
        }
    }
}
$userarray = [];
$strSQL = "SELECT * FROM users";
$rs = mysqli_query($conn, $strSQL);
while ($row = mysqli_fetch_array($rs)) {
    $userarray[] = ["user" => $row["username"], "traffic" => $row["traffic"]];
}
foreach ($userarray as $user) {
    $strSQL = "SELECT total FROM Traffic where user='" . $user["user"] . "'";
    $rs = mysqli_query($conn, $strSQL);
    while ($row = mysqli_fetch_array($rs)) {
        if ($user["traffic"] < $row["total"] && !empty($user["traffic"])) {
            echo $user["user"] . "<br>";
            $sql = "UPDATE users SET enable='traffic' where username='" . $user["user"] . "'";
            if ($conn->query($sql) === true) {
            }
            $out = shell_exec("bash /var/www/html/p/delete " . $user["user"]);
        }
    }
}
$conn->close();

?>