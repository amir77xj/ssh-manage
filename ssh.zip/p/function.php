<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

function gen_token()
{
    $length = 16;
    $alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $pass = [];
    $alphaLength = strlen($alphabet) - 1;
    for ($i = 0; $i < $length; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass);
}
function randomPassword($char_count, $type)
{
    $alphabet = $type;
    $pass = [];
    $alphaLength = strlen($alphabet) - 1;
    for ($i = 0; $i < $char_count; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass);
}
function isAllowed($ip, $whitelist)
{
    if (in_array($ip, $whitelist)) {
        return true;
    }
    foreach ($whitelist as $i) {
        $wildcardPos = strpos($i, "*");
        if ($wildcardPos !== false && substr($ip, 0, $wildcardPos) . "*" == $i) {
            return true;
        }
    }
    return false;
}
function response($Res, $response_code, $response_desc)
{
    $response["data"] = $Res;
    $response["response_code"] = $response_code;
    $response["response_desc"] = $response_desc;
    $json_response = json_encode($response, true);
    echo $json_response;
}
function formatBytes($bytes)
{
    if (0 < $bytes) {
        $i = floor(log($bytes) / log(1024));
        $sizes = [" بایت", " کیلوبایت", " مگ", " گیگ", " ترا", "PB", "EB", "ZB", "YB"];
        return sprintf("%.02F", round($bytes / pow(1024, $i), 1)) * 1 . " " . $sizes[$i];
    }
    return 0;
}

?>