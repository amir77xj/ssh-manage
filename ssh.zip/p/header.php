<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

include "config.php";
require "function.php";
$credit = 0;
$permission = "";
session_start();
if (!isset($_SESSION["username"])) {
    $_SESSION["msg"] = "You must log in first";
    header("location: login.php");
}
if (isset($_GET["logout"])) {
    session_destroy();
    unset($_SESSION["username"]);
    header("location: login.php");
}
global $permission;
$lisancemsg = file_get_contents("https://zarava.gold/msg.txt");
$lisancelist = file_get_contents("https://zarava.gold/list.txt");
if ($lisancemsg == "yes") {
    if (strpos($lisancelist, $_SERVER["SERVER_NAME"]) !== false) {
        $permission = "resettraffic,deleteuser,link,changepassword,bulkuser,setting,changelog,amoozesh,filter,online,menu,traffic,footer";
    } else {
        $permission = "proversion,deleteuser,link,changepassword,changelog,amoozesh,online,menu,footer";
    }
}
if ($lisancemsg == "no") {
    $permission = "proversion,resettraffic,deleteuser,link,changepassword,bulkuser,setting,changelog,amoozesh,filter,online,menu,traffic,footer";
}
if ($_SESSION["username"] !== $username && file_exists("/var/www/html/p/admin.php")) {
    $strSQL = "SELECT * FROM setting where adminuser='" . $_SESSION["username"] . "'";
    $rs = mysqli_query($conn, $strSQL);
    while ($row = mysqli_fetch_array($rs)) {
        $permission = $row["permissions"];
        $credit = $row["credit"];
    }
}
echo "<!DOCTYPE html>\r\n<html lang=\"en\" dir=\"rtl\">\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n    <meta name=\"description\" content=\"\">\r\n    <meta name=\"author\" content=\"HamedAp\">\r\n\t<title>ShaHaN Panel</title>\r\n    <link rel=\"icon\" type=\"image/png\" sizes=\"16x16\" href=\"favicon.svg\">\r\n    <link href=\"../plugins/bower_components/bootstrap-rtl-master/dist/css/bootstrap-rtl.min.css\" rel=\"stylesheet\">\r\n\t<link href=\"../plugins/bower_components/toast-master/css/jquery.toast.css\" rel=\"stylesheet\">\r\n    <link href=\"css/animate.css\" rel=\"stylesheet\">\r\n    <link href=\"css/style.css\" rel=\"stylesheet\">\r\n    <link href=\"css/colors/blue-dark.css\" id=\"theme\" rel=\"stylesheet\">\r\n\t<style>\r\n\t.checkip {\r\n    border: 1px solid #bdbdbd;\r\n\tpadding: 10px;\r\n    text-align: center;\r\n}\r\n@property --p{\r\n  syntax: '<number>';\r\n  inherits: true;\r\n  initial-value: 0;\r\n}\r\n.pie {\r\n  --p:20;\r\n  --b:22px;\r\n  --c:darkred;\r\n  --w:150px;\r\n  width:var(--w);\r\n  aspect-ratio:1;\r\n  position:relative;\r\n  display:inline-grid;\r\n  margin:5px;\r\n  place-content:center;\r\n  font-size:15px;\r\n  font-weight:bold;\r\n  font-family:sans-serif;\r\n}\r\n.pie:before,\r\n.pie:after {\r\n  content:\"\";\r\n  position:absolute;\r\n  border-radius:50%;\r\n}\r\n.pie:before {\r\n  inset:0;\r\n  background:\r\n    radial-gradient(farthest-side,var(--c) 98%,#0000) top/var(--b) var(--b) no-repeat,\r\n    conic-gradient(var(--c) calc(var(--p)*1%),#0000 0);\r\n  -webkit-mask:radial-gradient(farthest-side,#0000 calc(99% - var(--b)),#000 calc(100% - var(--b)));\r\n          mask:radial-gradient(farthest-side,#0000 calc(99% - var(--b)),#000 calc(100% - var(--b)));\r\n}\r\n.pie:after {\r\n  inset:calc(50% - var(--b)/2);\r\n  background:var(--c);\r\n  transform:rotate(calc(var(--p)*3.6deg)) translateY(calc(50% - var(--w)/2));\r\n}\r\n.animate {\r\n  animation:p 1s .5s both;\r\n}\r\n.no-round:before {\r\n  background-size:0 0,auto;\r\n}\r\n.no-round:after {\r\n  content:none;\r\n}\r\n@keyframes p {\r\n  from{--p:0}\r\n}\r\n\t</style>\r\n</head>\r\n";

?>