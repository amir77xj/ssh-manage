<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

include "header.php";
if ($_SESSION["username"] !== $username && file_exists("/var/www/html/p/admin.php")) {
    $sort = "desc";
    $strSQL = "SELECT * FROM users where referral='" . $_SESSION["username"] . "'";
    if ($_GET["sortby"] == "desc") {
        $strSQL = "select * from users where referral='" . $_SESSION["username"] . "' ORDER BY id desC;";
        $sort = "asc";
    }
    if ($_GET["sortby"] == "asc") {
        $strSQL = "select * from users where referral='" . $_SESSION["username"] . "' ORDER BY id asc;";
        $sort = "desc";
    }
    if ($_GET["sortby"] == "active") {
        $strSQL = "select * from users where enable='true' and referral='" . $_SESSION["username"] . "' ;";
    }
    if ($_GET["sortby"] == "deactive") {
        $strSQL = "SELECT * FROM users where enable not like 'true' and referral='" . $_SESSION["username"] . "' ;";
    }
    if ($_GET["sortby"] == "expired") {
        $strSQL = "select * from users where enable='expired' and referral='" . $_SESSION["username"] . "' ;";
    }
    if ($_GET["sortby"] == "traffic") {
        $strSQL = "select * from users where enable='traffic' and referral='" . $_SESSION["username"] . "' ;";
    }
    if ($_GET["sortby"] == "date") {
        $strSQL = "select * from users where referral='" . $_SESSION["username"] . "' ORDER BY finishdate asc;";
    }
} else {
    $sort = "desc";
    $strSQL = "SELECT * FROM users";
    if ($_GET["sortby"] == "desc") {
        $strSQL = "select * from users ORDER BY id desC;";
        $sort = "asc";
    }
    if ($_GET["sortby"] == "asc") {
        $strSQL = "select * from users ORDER BY id asc;";
        $sort = "desc";
    }
    if ($_GET["sortby"] == "active") {
        $strSQL = "select * from users where enable='true';";
    }
    if ($_GET["sortby"] == "deactive") {
        $strSQL = "SELECT * FROM users where enable not like 'true';";
    }
    if ($_GET["sortby"] == "expired") {
        $strSQL = "select * from users where enable='expired';";
    }
    if ($_GET["sortby"] == "traffic") {
        $strSQL = "select * from users where enable='traffic';";
    }
    if ($_GET["sortby"] == "date") {
        $strSQL = "select * from users ORDER BY finishdate asc;";
    }
}
if (!empty($_GET["activeuser"])) {
    $sql = "UPDATE users SET enable='true' where username='" . $_GET["activeuser"] . "'";
    if ($conn->query($sql) === true) {
    }
    $out = shell_exec("bash adduser " . $_GET["activeuser"] . " " . $_GET["password"]);
}
if (!empty($_GET["deactiveuser"])) {
    $sql = "UPDATE users SET enable='false' where username='" . $_GET["deactiveuser"] . "'";
    if ($conn->query($sql) === true) {
    }
    $out = shell_exec("bash delete " . $_GET["deactiveuser"]);
}
if (!empty($_GET["removeuser"])) {
    $sql = "delete FROM users where username='" . $_GET["removeuser"] . "'";
    if ($conn->query($sql) === true) {
    }
    $out = shell_exec("bash delete " . $_GET["removeuser"]);
    $sql = "delete FROM Traffic where user='" . $_GET["resettraffic"] . "'";
    if ($conn->query($sql) === true) {
    }
}
if (!empty($_GET["resettraffic"])) {
    $sql = "delete FROM Traffic where user='" . $_GET["resettraffic"] . "'";
    if ($conn->query($sql) === true) {
    }
}
include "menu.php";
echo "               <div class=\"row\">\n                <div class=\"col-md-12\">\n                    <div class=\"panel\">\n                        <div class=\"panel-heading\" style=\"display: inline-block;\">مدیریت کاربران</div>\n\t\t\t\t\t\t<a href=\"newuser.php\" class=\"btn btn-danger m-t-10 btn-rounded\">کاربر جدید</a>\n\t\t\t\t\t\t";
if (strpos($permission, "bulkuser") !== false) {
    echo "<a href=\"bulkuser.php\" class=\"btn btn-danger m-t-10 btn-rounded\">ساخت کاربر عمده </a>";
}
echo "\t\t\t\t\t\t\n\t\t\t\t\t\t";
if (!($_SESSION["username"] !== $username && file_exists("/var/www/html/p/admin.php"))) {
    echo "\t<div class=\"container mt-5\" style=\"max-width: 555px;margin: 20px;float: left;\">\n        <input type=\"text\" class=\"form-control\" name=\"live_search\" id=\"live_search\" autocomplete=\"off\"\n            placeholder=\"Search ...\">\n        <div id=\"search_result\" style=\"z-index: 999;width: 525px;position: absolute;\"></div>\n\t\t\t\t\t\t</div>";
}
echo "\t\t\t\t\t\t<div class=\"table-responsive\" style=\"padding-bottom: 200px !important;overflow: inherit;\">\n                            <table class=\"table table-hover manage-u-table\">\n                                <thead>\n\t\t\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t\t\t\t<th width=\"50\" class=\"text-center\"><a href=\"index.php?sortby=";
echo $sort;
echo "\"><i class=\"ti-arrow-up text-info\" style=\"font-size: 10px;\"></i><i class=\"ti-arrow-down text-info\" style=\"font-size: 10px;\"></i></a></th>\n                                        <th>نام کاربری</th>\n\t\t\t\t\t\t\t\t\t\t<th>رمز عبور</th>\n                                        <th>محدودیت</th>\n                                        <th>اطلاعات ارتباطی</th>\n                                        <th><a href=\"index.php?sortby=date\" >زمان <i class=\"ti-arrow-up text-info\" style=\"font-size: 10px;\"></i><i class=\"ti-arrow-down text-info\" style=\"font-size: 10px;\"></i></a></th>\n                                        <th>وضعیت</th>\n                                        <th>مدیریت کردن</th>\n\t\t\t\t\t\t\t\t\t\t<th>بازاریاب</th>\n                                    </tr>\n\t\t\t\t\t\t\t\t</thead>\n                                <tbody>\n\t\t\t\t\t\t\t\t";
$m = 1;
for ($rs = mysqli_query($conn, $strSQL); $row = mysqli_fetch_array($rs); $m++) {
    if ($row["enable"] == "true") {
        $status = "<a href=\"index.php?sortby=active\" class=\"btn btn-success m-t-10 btn-rounded\">فعال</a>";
    }
    if ($row["enable"] == "false") {
        $status = "<a href=\"index.php?sortby=deactive\" class=\"btn btn-danger m-t-10 btn-rounded\">غیرفعال</a>";
    }
    if ($row["enable"] == "expired") {
        $status = "<a href=\"index.php?sortby=expired\" class=\"btn btn-warning m-t-10 btn-rounded\">منقضی شده</a>";
    }
    if ($row["enable"] == "traffic") {
        $status = "<a href=\"index.php?sortby=traffic\" class=\"btn btn-warning m-t-10 btn-rounded\">اتمام ترافیک</a>";
    }
    if ($row["traffic"] !== "0") {
        if (1024 <= $row["traffic"]) {
            $traffic = $row["traffic"] / 1024 . " گیگابایت";
        } else {
            $traffic = $row["traffic"] . " مگابایت";
        }
    } else {
        $traffic = "نامحدود";
    }
    echo "\n\t\t\t\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t\t\t\t<td name=\"ip" . $m . "\" style=\"display:none;\">" . $_SERVER["SERVER_NAME"] . "</td>\n\t\t\t\t\t\t\t\t\t\t<td name=\"port" . $m . "\" style=\"display:none;\">" . $port . "</td>\n\t\t\t\t\t\t\t\t\t\t<td class=\"text-center\" name=\"id\">" . $m . "</td>\n\t\t\t\t\t\t\t\t\t\t<td name=\"username" . $m . "\">" . $row["username"] . "</td>\n\t\t\t\t\t\t\t\t\t\t<td name=\"password" . $m . "\">" . $row["password"] . "</td>\n\t\t\t\t\t\t\t\t\t\t<td><span name=\"traffic" . $m . "\" class=\"text-muted\">ترافیک : " . $traffic . "</span>\n\t\t\t\t\t\t\t\t\t\t\t<br><span name=\"multilogin" . $m . "\" class=\"text-muted\">کاربر همزمان : " . $row["multiuser"] . "</span></td>\n\t\t\t\t\t\t\t\t\t\t<td>" . $row["email"] . "\n\t\t\t\t\t\t\t\t\t\t\t<br><span class=\"text-muted\">" . $row["mobile"] . "</span></td>\n\t\t\t\t\t\t\t\t\t\t<td>تاریخ شروع : " . $row["startdate"] . "\n\t\t\t\t\t\t\t\t\t\t\t<br><span name=\"expire" . $m . "\" class=\"text-muted\">تاریخ انقضا : " . $row["finishdate"] . "</span></td>\n\t\t\t\t\t\t\t\t\t\t<td>\n\t\t\t\t\t\t\t\t\t\t\t" . $status . "\n\t\t\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t\t\t\t<td>\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"btn-group m-r-10\">\n                                    <button aria-expanded=\"false\" data-toggle=\"dropdown\" class=\"btn btn-default btn-outline dropdown-toggle waves-effect waves-light\" type=\"button\"> <i class=\"fa fa-cog m-r-5\"></i> <span class=\"caret\"></span></button>\n                                    <ul role=\"menu\" class=\"dropdown-menu\">\n                                        <li><a href=\"newuser.php?edituser=" . $row["username"] . "\">ویرایش</a></li>\n                                        <li><a href=\"index.php?activeuser=" . $row["username"] . "&password=" . $row["password"] . "\">فعال کردن</a></li>\n                                        <li><a href=\"index.php?deactiveuser=" . $row["username"] . "\">غیرفعال کردن</a></li>\n                                        <li class=\"divider\"></li>";
    if (strpos($permission, "resettraffic") !== false) {
        echo "\n\t\t\t\t\t\t\t\t\t\t<li><a href=\"index.php?resettraffic=" . $row["username"] . "\" style=\"color:Tomato;\">ریست ترافیک</a></li>";
    }
    if (strpos($permission, "deleteuser") !== false) {
        echo "<li><a href=\"index.php?removeuser=" . $row["username"] . "\" style=\"color:Tomato;\">حذف</a></li>";
    }
    echo "\n                                    </ul>\n                                </div>";
    if (strpos($permission, "link") !== false) {
        echo "\n\t\t\t\t\t\t\t\t<button type=\"button\" class=\"userinfo btn waves-effect waves-light btn-info\" onclick=\"getinfo(" . $m . ")\"><i class=\"fa fa-link\"></i></button>\n\t\t\t\t\t\t\t\t<button type=\"button\" class=\"userinfo btn waves-effect waves-light btn-success\" onclick=\"getqrcode(" . $m . ")\" style=\"margin-right: 10px;\"><i class=\"fa fa-qrcode\"></i></button>\n\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t<img class=\"qr-code" . $m . " img-thumbnail img-responsive\" style=\"display:none\"/>\n\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t";
    }
    echo "</td>\n\t\t\t\t\t\t\t\t\t\t<td>" . $row["referral"] . "</td>\n\t\t\t\t\t\t\t\t\t</tr>";
}
echo "                                </tbody>\n                            </table>\n                        </div>\n                    </div>\n                </div>\n            </div>\n\t\t\t</div>\n\t\t\t";
include "footer.php";

?>