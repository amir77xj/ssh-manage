#!/bin/bash
#By Hamed Ap

network=$(ip route get 8.8.8.8 | sed -nr 's/.*dev ([^\ ]+).*/\1/p')
ipipv6=$(ip -6 addr show dev ${network} scope global | sed -e's/^.*inet6 \([^ ]*\)\/.*$/\1/;t;d')

echo "$ipipv6" > ipv6.txt
