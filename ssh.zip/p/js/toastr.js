$(document).ready(function() {
      $(".tst1").click(function(){
           $.toast({
            heading: 'به صفحه مدیریتی مدیرخوب خوش آمدید',
            text: 'در این جا می توانید به تمامی موارد مدیریتی وب سایت خود دسترسی داشته باشید',
            position: 'top-right',
            loaderBg:'#ff6849',
            icon: 'info',
            hideAfter: 3000, 
            stack: 6
          });

     });

      $(".tst2").click(function(){
           $.toast({
            heading: 'به صفحه مدیریتی مدیرخوب خوش آمدید',
            text: 'در این جا می توانید به تمامی موارد مدیریتی وب سایت خود دسترسی داشته باشید',
            position: 'top-right',
            loaderBg:'#ff6849',
            icon: 'warning',
            hideAfter: 3500, 
            stack: 6
          });

     });
      $(".tst3").click(function(){
           $.toast({
            heading: 'به صفحه مدیریتی مدیرخوب خوش آمدید',
            text: 'در این جا می توانید به تمامی موارد مدیریتی وب سایت خود دسترسی داشته باشید',
            position: 'top-right',
            loaderBg:'#ff6849',
            icon: 'success',
            hideAfter: 3500, 
            stack: 6
          });

     });

      $(".tst4").click(function(){
           $.toast({
            heading: 'به صفحه مدیریتی مدیرخوب خوش آمدید',
            text: 'در این جا می توانید به تمامی موارد مدیریتی وب سایت خود دسترسی داشته باشید',
            position: 'top-right',
            loaderBg:'#ff6849',
            icon: 'error',
            hideAfter: 3500
            
          });

     });
     

});
          
