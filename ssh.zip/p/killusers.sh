#!/bin/bash
#By Hamed Ap

i=0
while [ $i -lt 30 ]; do 
php /var/www/html/p/kill.php &
  sleep 2
  i=$(( i + 1 ))
done
