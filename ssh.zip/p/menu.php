<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

global $list;
$list = shell_exec("sudo lsof -i :" . $port . " -n | grep -v root | grep ESTABLISHED");
if ($_SESSION["username"] !== $username && file_exists("/var/www/html/p/admin.php")) {
    $sql = "SELECT * FROM users where referral='" . $_SESSION["username"] . "'";
    if ($result = mysqli_query($conn, $sql)) {
        $usertotal = mysqli_num_rows($result);
    }
    $sql = "SELECT * FROM users where enable='true' and referral='" . $_SESSION["username"] . "'";
    if ($result = mysqli_query($conn, $sql)) {
        $useractive = mysqli_num_rows($result);
    }
    $sql = "SELECT * FROM users where enable not like 'true' and referral='" . $_SESSION["username"] . "'";
    if ($result = mysqli_query($conn, $sql)) {
        $userdeactive = mysqli_num_rows($result);
    }
    $userlist = [];
    $strSQL = "SELECT * FROM users where referral='" . $_SESSION["username"] . "'";
    $rs = mysqli_query($conn, $strSQL);
    while ($row = mysqli_fetch_array($rs)) {
        $userlist[] = $row["username"];
    }
    $onlineuserlist = preg_split("/\r\n|\n|\r/", $list);
    foreach ($onlineuserlist as $user) {
        $user = preg_replace("/\\s+/", " ", $user);
        $userarray = explode(" ", $user);
        $userarray[8] = strstr($userarray[8], "->");
        $userarray[8] = str_replace("->", "", $userarray[8]);
        $onlineuserip = substr($userarray[8], 0, strpos($userarray[8], ":"));
        if (in_array($userarray[2], $userlist) && !empty($userarray[2])) {
            $newlines[] = "AAAA:" . $userarray[1] . ":" . $userarray[2] . ":AAAA" . ":AAAA" . ":AAAA" . ":AAAA" . ":AAAA:" . $onlineuserip;
        }
    }
    $list = implode("\n", $newlines);
} else {
    $sql = "SELECT * FROM users";
    if ($result = mysqli_query($conn, $sql)) {
        $usertotal = mysqli_num_rows($result);
    }
    $sql = "SELECT * FROM users where enable='true'";
    if ($result = mysqli_query($conn, $sql)) {
        $useractive = mysqli_num_rows($result);
    }
    $sql = "SELECT * FROM users where enable not like 'true'";
    if ($result = mysqli_query($conn, $sql)) {
        $userdeactive = mysqli_num_rows($result);
    }
}
$free = shell_exec("free");
$free = (string) trim($free);
$free_arr = explode("\n", $free);
$mem = explode(" ", $free_arr[1]);
$mem = array_filter($mem, function ($value) {
    return $value !== NULL && $value !== false && $value !== "";
});
$mem = array_merge($mem);
$memtotal = round($mem[1] / 1000000, 2);
$memused = round($mem[2] / 1000000, 2);
$memfree = round($mem[3] / 1000000, 2);
$memtotal = str_replace(" GB", "", $memtotal);
$memused = str_replace(" GB", "", $memused);
$memfree = str_replace(" GB", "", $memfree);
$memtotal = str_replace(" MB", "", $memtotal);
$memused = str_replace(" MB", "", $memused);
$memfree = str_replace(" MB", "", $memfree);
$usedperc = 100 / $memtotal * $memused;
$exec_loads = sys_getloadavg();
$exec_cores = trim(shell_exec("grep -P '^processor' /proc/cpuinfo|wc -l"));
$cpu = round($exec_loads[1] / ($exec_cores + 1) * 100, 0);
$diskfree = round(disk_free_space(".") / 1000000000);
$disktotal = round(disk_total_space(".") / 1000000000);
$diskused = round($disktotal - $diskfree);
$diskusage = round($diskused / $disktotal * 100);
$traffic_rx = shell_exec("sudo netstat -e -n -i |  grep \"RX packets\" | grep -v \"RX packets 0\" | grep -v \" B)\"");
$traffic_tx = shell_exec("sudo netstat -e -n -i |  grep \"TX packets\" | grep -v \"TX packets 0\" | grep -v \" B)\"");
$res = preg_split("/\r\n|\n|\r/", $traffic_rx);
foreach ($res as $resline) {
    $resarray = explode(" ", $resline);
    $download += $resarray[13];
}
$res = preg_split("/\r\n|\n|\r/", $traffic_tx);
foreach ($res as $resline) {
    $resarray = explode(" ", $resline);
    $upload += $resarray[13];
}
$total = $download + $upload;
echo "<body class=\"fix-header\">\r\n    <div id=\"wrapper\">\r\n        <nav class=\"navbar navbar-default navbar-static-top m-b-0\">\r\n            <div class=\"navbar-header\">\r\n\t\t\t\t<ul class=\"nav navbar-top-links navbar-left\">\r\n                    <li><a href=\"javascript:void(0)\" class=\"open-close waves-effect waves-light visible-xs\"><i class=\"ti-close ti-menu\"></i></a></li>\r\n                </ul>\r\n                <div class=\"top-left-part\" style=\"width: 200px !important;\">\r\n                    <a class=\"logo\" href=\"index.php\" style=\"margin-right: 30px;\">صفحه اصلی</a>\r\n                </div>\r\n\t\t\t\t<ul class=\"nav navbar-top-links navbar-right pull-right\">\r\n                    <li class=\"dropdown\">\r\n                        <a class=\"dropdown-toggle profile-pic\" data-toggle=\"dropdown\" href=\"index.php#\" aria-expanded=\"false\"> <i class=\"ti-user\" style=\"margin-left: 10px;\"></i><b class=\"hidden-xs\" style=\"margin-left: 10px;\">پروفایل</b><span class=\"caret\"></span> </a>\r\n                        <ul class=\"dropdown-menu dropdown-user animated flipInY\">\r\n                            <li>\r\n                                <div class=\"dw-user-box\">\r\n                                    <div class=\"u-img\"><img src=\"img/profile.png\" alt=\"user\"></div>\r\n                                    <div class=\"u-text\">\r\n                                        <h4>نام کاربری : ";
echo $_SESSION["username"];
echo "</h4>\r\n                                </div>\r\n                            </li>\r\n\t\t\t\t\t\t\t";
if (!empty($credit) || $credit == 0) {
    echo "<li><a><i class=\"fa fa-money\"></i> اعتبار من : " . $credit . "</a></li>";
}
echo "                            <li role=\"separator\" class=\"divider\"></li>\r\n                            <li><a href=\"?logout=1\"><i class=\"fa fa-power-off\"></i> خروج</a></li>\r\n                        </ul>\r\n                        <!-- /.dropdown-user -->\r\n                    </li>\r\n                    <!-- /.dropdown -->\r\n                </ul>\r\n            </div>\r\n        </nav>\r\n        <div class=\"navbar-default sidebar\" role=\"navigation\">\r\n            <div class=\"sidebar-nav slimscrollsidebar\">\r\n                <div class=\"sidebar-head\">\r\n                    <h3><span class=\"fa-fw open-close\"><i class=\"ti-menu hidden-xs\"></i><i class=\"ti-close visible-xs\"></i></span> <span class=\"hide-menu\">منو</span></h3> \r\n\t\t\t\t</div>\r\n                <ul class=\"nav\" id=\"side-menu\">\r\n\t\t\t\t<li><a href=\"index.php\" class=\"waves-effect\"><i class=\"fa fa-home\"></i>  <span class=\"hide-menu\" style=\"margin-right: 5px !important;\">صفحه اصلی</span></a></li>\r\n\t\t\t\t\t";
if (strpos($permission, "setting") !== false) {
    echo "<li><a href=\"setting.php\" class=\"waves-effect\"><i class=\"fa fa-cog\"></i>  <span class=\"hide-menu\" style=\"margin-right: 5px !important;\">تنظیمات</span></a></li>";
}
echo "\t\t\t\t\t";
if ($_SESSION["username"] == $username && file_exists("/var/www/html/p/admin.php")) {
    echo "<li><a href=\"admin.php\" class=\"waves-effect\"><i class=\"fa fa-plus\"></i>  <span class=\"hide-menu\" style=\"margin-right: 5px !important;\">اضافه کردن بازاریاب</span></a></li>";
}
echo "\t\t\t\t\t";
if (strpos($permission, "amoozesh") !== false) {
    echo "<li><a href=\"https://konusanlar.tk/doc/\" class=\"waves-effect\"><i class=\"fa fa-book\"></i>  <span class=\"hide-menu\" style=\"margin-right: 5px !important;\">آموزش و مستندات</span></a></li>";
}
echo "\t\t\t\t\t";
if (strpos($permission, "filter") !== false) {
    echo "<li><a href=\"checkip.php\" class=\"waves-effect\"><i class=\"fa fa-lock\"></i>  <span class=\"hide-menu\" style=\"margin-right: 5px !important;\">وضعیت فیلترینگ</span></a></li>";
}
echo "                \t";
if (strpos($permission, "changelog") !== false) {
    echo "<li><a href=\"changelog.php\" class=\"waves-effect\"><i class=\"fa fa-refresh\"></i>  <span class=\"hide-menu\" style=\"margin-right: 5px !important;\">تغییرات آپدیت</span></a></li>";
}
echo "\t\t\t\t\t";
if (strpos($permission, "proversion") !== false) {
    echo "<li><a href=\"http://konusanlar.tk\" class=\"waves-effect\"><i class=\"fa fa-star-o text-warning\"></i>  <span class=\"hide-menu text-warning\" style=\"margin-right: 5px !important;\">نسخه حرفه ای</span></a></li>";
}
echo "\t\t\t\t\t<li><a href=\"?logout=1\" class=\"waves-effect\"><i class=\"fa fa-power-off\"></i>  <span class=\"hide-menu text-danger\" style=\"margin-right: 5px !important;\">خروج</span></a></li>\r\n               </ul>\r\n            </div>\r\n        </div>\r\n\t\t<div id=\"page-wrapper\">\r\n            <div class=\"container-fluid\">\r\n                <div class=\"row\" style=\"margin-top: 10px !important;\" >\r\n\t\t\t\t\t\t\t";
if (strpos($permission, "menu") !== false) {
    echo "\t\t\t\t\t\t\t<div class=\"col-lg-3 col-sm-6 col-xs-12\">\r\n                                <div class=\"white-box\" style=\"padding: 7px !important;\">\r\n                                    <a style=\"padding-left: 80px;padding-right: 15px;\">مصرف رم : </a>\r\n\t\t\t\t\t\t\t\t\t<div class=\"pie animate no-round\" style=\"--p:";
    echo round($usedperc);
    echo ";--c:orange;\"> ";
    echo round($usedperc);
    echo "%</div>\r\n                                </div>\r\n                            </div>\r\n\t\t\t\t\t\t\t<div class=\"col-lg-3 col-sm-6 col-xs-12\">\r\n                                <div class=\"white-box\" style=\"padding: 7px !important;\">\r\n                                    <a style=\"padding-left: 35px;padding-right: 15px;\">مصرف سی پی یو : </a>\r\n\t\t\t\t\t\t\t\t\t<div class=\"pie animate no-round\" style=\"--p:";
    echo round($cpu);
    echo ";--c:orange;\"> ";
    echo round($cpu);
    echo "%</div>\r\n                                </div>\r\n                            </div>\r\n\t\t\t\t\t\t\t<div class=\"col-lg-3 col-sm-6 col-xs-12\">\r\n                                <div class=\"white-box\" style=\"padding: 7px !important;\">\r\n                                    <a style=\"padding-left: 60px;padding-right: 15px;\">مصرف هارد : </a>\r\n\t\t\t\t\t\t\t\t\t<div class=\"pie animate no-round\" style=\"--p:";
    echo round($diskusage);
    echo ";--c:orange;\"> ";
    echo round($diskusage);
    echo "%</div>\r\n                                </div>\r\n                            </div>\r\n\t\t\t\t\t\t\t<div class=\"col-lg-3 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t\t<a href=\"traffic.php\">\r\n                                <div class=\"white-box\" style=\"padding:35px;padding-bottom: 32px;\">\r\n                                    <h3 class=\"box-title\">ترافیک مصرف شده</h3>\r\n                                    <ul class=\"list-inline two-part\">\r\n                                        <li><i class=\"icon-globe text-info\"></i></li>\r\n                                        <li class=\"text-right\"><span class=\"counter\" style=\"font-size: 25px;\">";
    echo formatBytes($total);
    echo "</span></li>\r\n                                    </ul>\r\n                                </div>\r\n\t\t\t\t\t\t\t\t</a>\r\n                            </div>\r\n\t\t\t\t\t\t\t";
}
echo "                            <div class=\"col-lg-3 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t\t<a href=\"index.php\">\r\n                                <div class=\"white-box\">\r\n                                    <h3 class=\"box-title\">کل کاربران</h3>\r\n                                    <ul class=\"list-inline two-part\">\r\n                                        <li><i class=\"icon-people text-info\"></i></li>\r\n                                        <li class=\"text-right\"><span class=\"counter\">";
echo $usertotal;
echo "</span></li>\r\n                                    </ul>\r\n                                </div>\r\n\t\t\t\t\t\t\t</a>\r\n                            </div>\r\n                            <div class=\"col-lg-3 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t\t<a href=\"online.php\">\r\n                                <div class=\"white-box\">\r\n                                    <h3 class=\"box-title\">کاربران آنلاین</h3>\r\n                                    <ul class=\"list-inline two-part\">\r\n                                        <li><i class=\"icon-people text-warning\"></i></li>\r\n                                        <li class=\"text-right\"><span class=\"counter\">";
if ($_SESSION["username"] !== $username && file_exists("/var/www/html/p/admin.php")) {
    echo count($newlines);
} else {
    echo substr_count($list, "\n");
}
echo "</span></li>\r\n                                    </ul>\r\n                                </div>\r\n\t\t\t\t\t\t\t\t</a>\r\n                            </div>\r\n                            <div class=\"col-lg-3 col-sm-6 col-xs-12\">\r\n                                <div class=\"white-box\">\r\n                                    <h3 class=\"box-title\">کاربران فعال</h3>\r\n                                    <ul class=\"list-inline two-part\">\r\n                                        <li><i class=\"icon-people text-success\"></i></li>\r\n                                        <li class=\"text-right\"><span class=\"\">";
echo $useractive;
echo "</span></li>\r\n                                    </ul>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-lg-3 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t\t<a href=\"index.php?sortby=deactive\">\r\n                                <div class=\"white-box\">\r\n                                    <h3 class=\"box-title\">کاربران غیرفعال</h3>\r\n                                    <ul class=\"list-inline two-part\">\r\n                                        <li><i class=\"icon-people text-danger\"></i></li>\r\n                                        <li class=\"text-right\"><span class=\"\">";
echo $userdeactive;
echo "</span></li>\r\n                                    </ul>\r\n                                </div>\r\n\t\t\t\t\t\t\t</a>\r\n                            </div>\r\n                        </div>";

?>