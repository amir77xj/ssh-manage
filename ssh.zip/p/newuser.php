<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

include "header.php";
if ($_SESSION["username"] !== $username && file_exists("/var/www/html/p/admin.php")) {
    if (!empty($_POST["resellernew"]) && !empty($_POST["user"]) && !empty($_POST["password"])) {
        $sql = "SELECT * FROM users where username='" . strtolower($_POST["user"]) . "'";
        if ($result = mysqli_query($conn, $sql)) {
            $userexist = mysqli_num_rows($result);
        }
        if ($userexist == "0") {
            if (is_numeric(strtolower($_POST["user"]))) {
                $msg = "<div class=\"alert alert-warning alert-dismissable\">\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\nنام کاربری فقط حروف انگلیسی مورد قبول است .\n</div>";
            } else {
                $account = 1;
                if ($_POST["accountmonth"] == "1m") {
                    $account = 1;
                }
                if ($_POST["accountmonth"] == "2m") {
                    $account = 2;
                }
                if ($_POST["accountmonth"] == "3m") {
                    $account = 3;
                }
                $expdate = date("Y-m-d", strtotime(date("Y-m-d", strtotime(date("Y-m-d"))) . "+" . $account . " month"));
                $newcredit = $credit - $account;
                if ($newcredit < 0) {
                    $msg = "<div class=\"alert alert-warning alert-dismissable\">\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\nاعتبار شما کافی نمی باشد .\n</div>";
                } else {
                    $adduser = "INSERT INTO `users` (\n `username`,\n `password`,\n `mobile`,\n `multiuser` ,\n `startdate`,\n `finishdate`,\n `enable`,\n `traffic`,\n `referral`,\n `info` ) VALUES (\n '" . strtolower($_POST["user"]) . "',\n '" . $_POST["password"] . "',\n '" . $_POST["mobile"] . "',\n '1',\n '',\n '" . $expdate . "',\n 'true',\n '0',\n '" . $_SESSION["username"] . "',\n '" . $_POST["info"] . "' );";
                    if ($conn->query($adduser) === true) {
                    }
                    $out = shell_exec("bash adduser " . strtolower($_POST["user"]) . " " . $_POST["password"]);
                    $sql = "UPDATE setting SET credit='" . $newcredit . "'  where adminuser='" . $_SESSION["username"] . "'";
                    if ($conn->query($sql) === true) {
                    }
                    header("Location: index.php");
                }
            }
        } else {
            $msg = "<div class=\"alert alert-warning alert-dismissable\">\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\nنام کاربری تکراری میباشد .\n</div>";
        }
    }
    if (isset($_GET["edituser"])) {
        $strSQL = "SELECT * FROM users where username='" . $_GET["edituser"] . "'";
        $rs = mysqli_query($conn, $strSQL);
        while ($row = mysqli_fetch_array($rs)) {
            $editusername = $row["username"];
            $editpassword = $row["password"];
            $editemail = $row["email"];
            $editmobile = $row["mobile"];
            $editmultiuser = $row["multiuser"];
            $editfinishdate = $row["finishdate"];
            $edittraffic = $row["traffic"];
            $editreferral = $row["referral"];
            $editenable = $row["enable"];
            $editinfo = $row["info"];
        }
    }
    if (!empty($_POST["reselleredit"])) {
        if (!empty($_POST["tamdidmonth"])) {
            if ($_POST["tamdidmonth"] == "1m") {
                $account = 1;
            }
            if ($_POST["tamdidmonth"] == "2m") {
                $account = 2;
            }
            if ($_POST["tamdidmonth"] == "3m") {
                $account = 3;
            }
            $expdate = date("Y-m-d", strtotime($_POST["finishdate2"] . " + " . $account . " month"));
            $newcredit = $credit - $account;
            if ($newcredit < 0) {
                $msg = "<div class=\"alert alert-warning alert-dismissable\">\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\nاعتبار شما کافی نمی باشد .\n</div>";
            } else {
                $sql = "UPDATE users SET finishdate='" . $expdate . "',info='" . $_POST["info"] . "',password='" . $_POST["password"] . "',mobile='" . $_POST["mobile"] . "' where username='" . $_POST["useruser"] . "'";
                if ($conn->query($sql) === true) {
                }
                $sql = "UPDATE setting SET credit='" . $newcredit . "'  where adminuser='" . $_SESSION["username"] . "'";
                if ($conn->query($sql) === true) {
                }
            }
        } else {
            $sql = "UPDATE users SET info='" . $_POST["info"] . "',password='" . $_POST["password"] . "',mobile='" . $_POST["mobile"] . "' where username='" . $_POST["useruser"] . "'";
            if ($conn->query($sql) === true) {
            }
        }
        $out = shell_exec("bash ch " . $_POST["tamdidmonth"] . " " . $_POST["password"]);
    }
    include "menu.php";
    echo "\t<div class=\"row\">\n                <div class=\"col-md-12\">\n                    <div class=\"panel\">\n                        <div class=\"panel-heading\" style=\"display: inline-block;\">ثبت کاربر جدید</div>\n\t\t\t\t\t\t";
    if (strpos($permission, "bulkuser") !== false) {
        echo "<a href=\"bulkuser.php\" class=\"btn btn-danger m-t-10 btn-rounded\">ساخت کاربر عمده </a>";
    }
    echo "\t\t\t\t\t\t";
    echo $msg;
    echo "\t\t\t\t\t\t<div class=\"table-responsive\" >\n\t\t\t\t\t\t<form action=\"newuser.php\" method=\"post\">\n                        <div class=\"col-md-6\">\n\t\t\t\t\t\t\t<div class=\"white-box\">\n\t\t\t\t\t\t\t\t<div class=\"row\">\n\t\t\t\t\t\t\t\t\t<div class=\"col-sm-12 col-xs-12\">\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputEmail1\">نام کاربری (الزامی) : </label>\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"user\" type=\"text\" class=\"form-control\" id=\"exampleInputEmail1\" placeholder=\"Username\" value=\"";
    echo $editusername;
    echo "\" ";
    if (!empty($editusername)) {
        echo "disabled";
    }
    echo ">\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"useruser\" type=\"hidden\" value=\"";
    echo $_GET["edituser"];
    echo "\" >\n\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\" style=\"display: block;\">پسورد (الزامی) : </label>\n\t\t\t\t\t\t\t\t\t\t\t\t<input style=\"width: 92%;display: inline-block;\" name=\"password\" type=\"text\" class=\"form-control\" id=\"exampleInputPassword1\" placeholder=\"Password\" value=\"";
    echo $editpassword;
    echo "\">\n\t\t\t\t\t\t\t\t\t\t\t\t<button alt=\"Generate Random Password\" style=\"width: 7%;\" type=\"button\" class=\"randompassword btn waves-effect waves-light \"><i class=\"fa fa-refresh\"></i></button>\n\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t";
    if (!empty($editusername)) {
        echo "<div class=\"form-group\">\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">تاریخ انقضا</label>\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"finishdate\" type=\"text\" class=\"form-control\" id=\"exampleInputPassword1\"  value=\"" . $editfinishdate . "\" disabled>\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"finishdate2\" type=\"hidden\" class=\"form-control\" id=\"exampleInputPassword1\"  value=\"" . $editfinishdate . "\">\n\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t<p>تمدید اکانت</p>\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"radio radio-success\">\n\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"tamdidmonth\" id=\"radio21\" value=\"1m\" >\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"radio21\" style=\"margin-right: 40px;\"> یکماهه </label>\n\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"tamdidmonth\" id=\"radio22\" value=\"2m\" >\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"radio22\" style=\"margin-right: 40px;\"> دوماهه </label>\n\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"tamdidmonth\" id=\"radio23\" value=\"3m\" >\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"radio23\" style=\"margin-right: 40px;\"> سه ماهه </label>\n\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t";
    } else {
        echo "<div class=\"radio radio-success\">\n\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"accountmonth\" id=\"radio4\" value=\"1m\" checked>\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"radio4\" style=\"margin-right: 40px;\"> یکماهه </label>\n\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"accountmonth\" id=\"radio6\" value=\"2m\" >\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"radio6\" style=\"margin-right: 40px;\"> دوماهه </label>\n\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"accountmonth\" id=\"radio8\" value=\"3m\" >\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"radio8\" style=\"margin-right: 40px;\"> سه ماهه </label>\n\t\t\t\t\t\t\t\t\t\t\t</div>";
    }
    echo "\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">موبایل : </label>\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"mobile\" type=\"text\" class=\"form-control\" id=\"exampleInputPassword1\" placeholder=\"Mobile\" value=\"";
    echo $editmobile;
    echo "\">\n\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\n\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-12\">توضیحات : </label>\n\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-12\">\n\t\t\t\t\t\t\t\t\t\t\t\t<textarea name=\"info\" class=\"form-control\" rows=\"5\">";
    echo $editinfo;
    echo "</textarea>\n\t\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t</br>\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\" style=\"float: left;\">\n\t\t\t\t\t\t\t\t\t\t\t";
    if (!empty($editusername)) {
        echo "<button name=\"reselleredit\" type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\" value=\"reselleredit\" >ویرایش کاربر</button>";
    } else {
        echo "<button name=\"resellernew\" type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\" value=\"resellernew\" >ثبت</button>";
    }
    echo "\t\t\t\t\t\t\t\t\t\t\t<a href=\"index.php\" class=\"btn btn-inverse waves-effect waves-light\">انصراف</a>\n\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t</form>\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t</div>\n                    </div>\n                </div>\n            </div>\n\t\t\t</div>\n";
} else {
    $editusername = "";
    $editpassword = "";
    $editemail = "";
    $editmobile = "";
    $editmultiuser = "0";
    $editfinishdate = "";
    $edittraffic = "0";
    $editreferral = "";
    $editinfo = "";
    if (!empty($_POST["submitnewuser"]) && !empty($_POST["user"]) && !empty($_POST["password"])) {
        $sql = "SELECT * FROM users where username='" . strtolower($_POST["user"]) . "'";
        if ($result = mysqli_query($conn, $sql)) {
            $userexist = mysqli_num_rows($result);
        }
        if ($userexist == "0") {
            if (is_numeric(strtolower($_POST["user"]))) {
                $msg = "<div class=\"alert alert-warning alert-dismissable\">\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\nنام کاربری فقط حروف انگلیسی مورد قبول است .\n</div>";
            } else {
                if ($_POST["trafficsize"] == "gb") {
                    $traffic = $_POST["traffic"] * 1024;
                } else {
                    $traffic = $_POST["traffic"];
                }
                $exp = $_POST["finishdate"];
                if (!empty($_POST["dayadd"])) {
                    $exp = date("Y-m-d", strtotime(date("Y-m-d", strtotime(date("Y-m-d"))) . "+" . $_POST["dayadd"] . " day"));
                }
                $adduser = "INSERT INTO `users` (\n `username`,\n `password`,\n `email`,\n `mobile`,\n `multiuser` ,\n `startdate`,\n `finishdate`,\n `enable`,\n `traffic`,\n `referral`,\n `info` ) VALUES (\n '" . strtolower($_POST["user"]) . "',\n '" . $_POST["password"] . "',\n '" . $_POST["email"] . "',\n '" . $_POST["mobile"] . "',\n '" . $_POST["multiuser"] . "',\n '',\n '" . $exp . "',\n 'true',\n '" . $traffic . "',\n '" . $_POST["referral"] . "',\n '" . $_POST["info"] . "' );";
                if ($conn->query($adduser) === true) {
                }
                $out = shell_exec("bash adduser " . strtolower($_POST["user"]) . " " . $_POST["password"]);
                header("Location: index.php");
            }
        } else {
            $msg = "<div class=\"alert alert-warning alert-dismissable\">\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\nنام کاربری تکراری میباشد .\n</div>";
        }
    }
    if (isset($_GET["edituser"])) {
        $strSQL = "SELECT * FROM users where username='" . $_GET["edituser"] . "'";
        $rs = mysqli_query($conn, $strSQL);
        while ($row = mysqli_fetch_array($rs)) {
            $editusername = $row["username"];
            $editpassword = $row["password"];
            $editemail = $row["email"];
            $editmobile = $row["mobile"];
            $editmultiuser = $row["multiuser"];
            $editfinishdate = $row["finishdate"];
            $edittraffic = $row["traffic"];
            $editreferral = $row["referral"];
            $editenable = $row["enable"];
            $editinfo = $row["info"];
        }
    }
    if (!empty($_POST["editnewuser"])) {
        if ($_POST["trafficsize"] == "gb") {
            $traffic = $_POST["traffic"] * 1024;
        } else {
            $traffic = $_POST["traffic"];
        }
        $sql = "UPDATE users SET info='" . $_POST["info"] . "',password='" . $_POST["password"] . "',email='" . $_POST["email"] . "',mobile='" . $_POST["mobile"] . "',multiuser='" . $_POST["multiuser"] . "',finishdate='" . $_POST["finishdate"] . "',traffic='" . $traffic . "',referral='" . $_POST["referral"] . "' where username='" . $_POST["useruser"] . "'";
        if ($conn->query($sql) === true) {
        }
        $out = shell_exec("bash ch " . $_POST["useruser"] . " " . $_POST["password"]);
    }
    include "menu.php";
    echo "                <div class=\"row\">\n                <div class=\"col-md-12\">\n                    <div class=\"panel\">\n                        <div class=\"panel-heading\" style=\"display: inline-block;\">ثبت کاربر جدید</div>\n\t\t\t\t\t\t<a href=\"bulkuser.php\" class=\"btn btn-danger m-t-10 btn-rounded\">ساخت کاربر عمده </a>\n\t\t\t\t\t\t";
    echo $msg;
    echo "\t\t\t\t\t\t<div class=\"table-responsive\" >\n\t\t\t\t\t\t<form action=\"newuser.php\" method=\"post\">\n                        <div class=\"col-md-6\">\n\t\t\t\t\t\t\t<div class=\"white-box\">\n\t\t\t\t\t\t\t\t<div class=\"row\">\n\t\t\t\t\t\t\t\t\t<div class=\"col-sm-12 col-xs-12\">\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputEmail1\">نام کاربری (الزامی) : </label>\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"user\" type=\"text\" class=\"form-control\" id=\"exampleInputEmail1\" placeholder=\"Username\" value=\"";
    echo $editusername;
    echo "\" ";
    if (!empty($editusername)) {
        echo "disabled";
    }
    echo ">\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"useruser\" type=\"hidden\" value=\"";
    echo $_GET["edituser"];
    echo "\" >\n\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\" style=\"display: block;\">پسورد (الزامی) : </label>\n\t\t\t\t\t\t\t\t\t\t\t\t<input style=\"width: 92%;display: inline-block;\" name=\"password\" type=\"text\" class=\"form-control\" id=\"exampleInputPassword1\" placeholder=\"Password\" value=\"";
    echo $editpassword;
    echo "\">\n\t\t\t\t\t\t\t\t\t\t\t\t<button alt=\"Generate Random Password\" style=\"width: 7%;\" type=\"button\" class=\"randompassword btn waves-effect waves-light \"><i class=\"fa fa-refresh\"></i></button>\n\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">ایمیل : </label>\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"email\" type=\"text\" class=\"form-control\" id=\"exampleInputPassword1\" placeholder=\"Email\" value=\"";
    echo $editemail;
    echo "\">\n\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">موبایل : </label>\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"mobile\" type=\"text\" class=\"form-control\" id=\"exampleInputPassword1\" placeholder=\"Mobile\" value=\"";
    echo $editmobile;
    echo "\">\n\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\n\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-12\">توضیحات : </label>\n\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-12\">\n\t\t\t\t\t\t\t\t\t\t\t\t<textarea name=\"info\" class=\"form-control\" rows=\"5\">";
    echo $editinfo;
    echo "</textarea>\n\t\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<div class=\"col-md-6\">\n\t\t\t\t\t\t\t<div class=\"white-box\">\n\t\t\t\t\t\t\t\t<div class=\"row\">\n\t\t\t\t\t\t\t\t\t<div class=\"col-sm-12 col-xs-12\">\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">کاربر همزمان : </label>\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"multiuser\" type=\"text\" class=\"form-control\" id=\"exampleInputPassword1\" placeholder=\"Multi User Count\" value=\"";
    if (empty($editmultiuser)) {
        echo "1";
    } else {
        echo $editmultiuser;
    }
    echo "\">\n\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t<ul class=\"nav nav-tabs\" role=\"tablist\">\n\t\t\t\t\t\t\t\t\t\t\t\t<li role=\"presentation\" class=\"active\"><a href=\"newuser.php#date\" aria-controls=\"date\" role=\"tab\" data-toggle=\"tab\" aria-expanded=\"true\"><span class=\"visible-xs\"><i class=\"ti-date\"></i></span><span class=\"hidden-xs\"> تاریخ انقضا</span></a></li>\n\t\t\t\t\t\t\t\t\t\t\t\t<li role=\"presentation\" class=\"\"><a href=\"newuser.php#day\" aria-controls=\"day\" role=\"tab\" data-toggle=\"tab\" aria-expanded=\"false\"><span class=\"visible-xs\"><i class=\"ti-date\"></i></span> <span class=\"hidden-xs\">تعداد روز</span></a></li>\n\t\t\t\t\t\t\t\t\t\t\t</ul>\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"tab-content\">\n\t\t\t\t\t\t\t\t\t\t\t\t<div role=\"tabpanel\" class=\"tab-pane active\" id=\"date\">\n\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">تاریخ انقضا : </label>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"finishdate\" type=\"date\" class=\"form-control\" id=\"exampleInputPassword1\" placeholder=\"Expire Date\" value=\"";
    echo $editfinishdate;
    echo "\">\n\t\t\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"clearfix\"></div>\n\t\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t\t<div role=\"tabpanel\" class=\"tab-pane\" id=\"day\">\n\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">تعداد روز : </label>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"dayadd\" type=\"number\" class=\"form-control\" id=\"exampleInputPassword1\" >\n\t\t\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"clearfix\"></div>\n\t\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">ترافیک : </label>\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"traffic\" type=\"number\" class=\"form-control\" id=\"exampleInputPassword1\" placeholder=\"Traffic Usage\" value=\"";
    echo $edittraffic;
    echo "\" >\n\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"radio radio-success\">\n\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"trafficsize\" id=\"radio4\" value=\"mb\" checked>\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"radio4\"> مگابایت </label>\n\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"trafficsize\" id=\"radio6\" value=\"gb\">\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"radio6\" style=\"margin-right: 20px;\"> گیگابایت </label>\n\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">معرف : </label>\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"referral\" type=\"text\" class=\"form-control\" id=\"exampleInputPassword1\" placeholder=\"Referral\" value=\"";
    echo $editreferral;
    echo "\">\n\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\" style=\"float: left;\">\n\t\t\t\t\t\t\t\t\t\t\t";
    if (!empty($editusername)) {
        echo "<button name=\"editnewuser\" type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\" value=\"editnewuser\" >ویرایش کاربر</button>";
    } else {
        echo "<button name=\"submitnewuser\" type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\" value=\"submitnewuser\" >ثبت</button>";
    }
    echo "\t\t\t\t\t\t\t\t\t\t\t<a href=\"index.php\" class=\"btn btn-inverse waves-effect waves-light\">انصراف</a>\n\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t</form>\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t</div>\n                    </div>\n                </div>\n            </div>\n\t\t\t</div>\n";
}
include "footer.php";

?>