<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

if ($_GET["killid"]) {
    $out = shell_exec("sudo kill -9 " . $_GET["killid"]);
}
if ($_GET["username"]) {
    $out = shell_exec("sudo killall -u " . $_GET["username"]);
}
include "header.php";
include "menu.php";
echo "                <div class=\"row\">\r\n                <div class=\"col-md-12\">\r\n                    <div class=\"panel\">\r\n                        <div class=\"panel-heading\" style=\"display: inline-block;\">لیست کاربران آنلاین</div>\r\n\t\t\t\t\t\t<div class=\"table-responsive\">\r\n                            <table class=\"table table-hover manage-u-table\">\r\n                                <thead>\r\n\t\t\t\t\t\t\t\t <tr>\r\n                                        <th width=\"70\" class=\"text-center\">#</th>\r\n                                        <th>نام کاربری</th>\r\n                                        <th>IP</th>\r\n                                        <th></th>\r\n                                        <th></th>\r\n                                        <th width=\"250\"></th>\r\n                                        <th width=\"300\">مدیریت کردن</th>\r\n                                    </tr>\r\n                                </thead>\r\n                                <tbody>\r\n\t\t\t\t\t\t\t\t";
$duplicate = [];
$m = 1;
$onlineuserlist = preg_split("/\r\n|\n|\r/", $list);
foreach ($onlineuserlist as $user) {
    $user = preg_replace("/\\s+/", " ", $user);
    if (strpos($user, ":AAAA") !== false) {
        $userarray = explode(":", $user);
    } else {
        $userarray = explode(" ", $user);
    }
    if (strpos($userarray[8], "->") !== false) {
        $userarray[8] = strstr($userarray[8], "->");
        $userarray[8] = str_replace("->", "", $userarray[8]);
        $userip = substr($userarray[8], 0, strpos($userarray[8], ":"));
    } else {
        $userip = $userarray[8];
    }
    $color = "#fdaeae";
    if (!in_array($userarray[2], $duplicate)) {
        $color = "#97f997";
        array_push($duplicate, $userarray[2]);
    }
    if (!empty($userarray[2]) && $userarray[2] !== "sshd") {
        echo "<tr style=\"background-color:" . $color . " !important\">\r\n                                        <td class=\"text-center\">" . $m . "</td>\r\n                                        <td><span class=\"font-medium\">" . $userarray[2] . "</span></td>\r\n                                        <td><span class=\"font-medium\">" . $userip . "</span></td>\r\n                                        <td></td>\r\n                                        <td></td>\r\n                                        <td></td>\r\n                                        <td><a href=\"/p/online.php?username=" . $userarray[2] . "\"><span class=\"label label-danger\">Kill All User</span></a>\r\n\t\t\t\t\t\t\t\t\t\t<a href=\"/p/online.php?killid=" . $userarray[1] . "\"><span class=\"label label-danger\">Kill User</span></a></td>\r\n                                    </tr>";
    }
    $m++;
}
echo "                                </tbody>\r\n                            </table>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n\t\t\t</div>\r\n            ";
include "footer.php";

?>