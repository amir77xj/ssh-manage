<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

include "config.php";
$url = "http://" . $_SERVER["SERVER_ADDR"] . "/p/synctraffic.php";
$json = file_get_contents($url);
$data = json_decode($json, true);
foreach ($data as $user => $value) {
    $strSQL = "select * from Traffic where user='" . $user . "' ;";
    $rs = mysqli_query($conn, $strSQL);
    while ($row = mysqli_fetch_array($rs)) {
        $userdownload = $row["download"];
        $userupload = $row["upload"];
        $usertotal = $row["total"];
    }
    $lastdownload = $userdownload + $value["RX"];
    $lastupload = $userupload + $value["TX"];
    $lasttotal = $usertotal + $value["Total"];
    $sql = "REPLACE INTO `Traffic` (`user`, `upload`, `download`,`total`) VALUES ('" . $user . "','" . $lastupload . "','" . $lastdownload . "','" . $lasttotal . "')";
    if ($conn->query($sql) !== true) {
    }
}
$out = shell_exec("sudo killall -9 nethogs");
sleep(2);
$startnethogs = shell_exec("sudo nethogs -j -d 5 -v 3 > /var/www/html/p/log/out.json &");
$conn->close();

?>