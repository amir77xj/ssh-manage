<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

global $msg;
include "header.php";
include "menu.php";
$date = date("Y-m-d");
if (!empty($_POST["uploadsql"])) {
    $target_file = "backup/" . basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    if ($imageFileType != "sql") {
        $msg = "<div class=\"alert alert-danger alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nفقط فایل های SQL پشتیبانی میشود .\r\n</div>";
        $uploadOk = 0;
    }
    if ($uploadOk != 0) {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nفایل با موفقیت آپلود شد .\r\n</div>";
        } else {
            $msg = "<div class=\"alert alert-danger alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nخطای آپلود .\r\n</div>";
        }
    }
}
if (!empty($_GET["file"])) {
    if (strpos($_GET["file"], ".sql") !== false) {
        $output = shell_exec("mysql -u " . $username . " --password=" . $password . " ShaHaN < /var/www/html/p/backup/" . $_GET["file"]);
        $sql = "SELECT * FROM users where enable='true'";
        $rs = mysqli_query($conn, $sql);
        while ($row = mysqli_fetch_array($rs)) {
            $out = shell_exec("bash adduser " . $row["username"] . " " . $row["password"]);
            $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nبازگردانی کاربران با موفقیت انجام شد\r\n</div>";
        }
    } else {
        $msg = "<div class=\"alert alert-danger alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nفقط فایل های SQL پشتیبانی میشود .\r\n</div>";
    }
}
echo "                <div class=\"row\">\r\n                <div class=\"col-md-12\">\r\n                    <div class=\"panel\">\r\n                        <div class=\"panel-heading\" style=\"display: inline-block;\">بازگردانی بکاپ کاربران</div>\r\n\t\t\t\t\t\t";
echo $msg;
echo "\t\t\t\t\t\t<div class=\"table-responsive\">\r\n\t\t\t\t\t\t<form action=\"restore.php\" method=\"post\" style=\"display:block;\" enctype=\"multipart/form-data\">\r\n\t\t\t\t\t\t<input type=\"file\" name=\"fileToUpload\" id=\"fileToUpload\" style=\"float: right !important;margin-left: 20px!important;display: inline !important;margin-right: 50px;\">\r\n\t\t\t\t\t\t<button name=\"uploadsql\" type=\"submit\" class=\"btn-rounded btn btn-primary pull-right waves-effect waves-light\" value=\"upload\" style=\"float: right !important;margin-left: 40px!important;\" >آپلود بکاپ</button>\r\n\t\t\t\t\t\t</form>\r\n\t\t\t\t\t\t<table class=\"table table-hover manage-u-table\">\r\n                                <thead>\r\n\t\t\t\t\t\t\t\t <tr>\r\n                                        <th width=\"70\" class=\"text-center\">#</th>\r\n                                        <th>تاریخ بکاپ</th>\r\n                                        <th></th>\r\n                                        <th></th>\r\n                                        <th></th>\r\n                                        <th width=\"250\"></th>\r\n                                        <th width=\"300\">دریافت</th>\r\n                                    </tr>\r\n                                </thead>\r\n                                <tbody>\r\n\t\t\t\t\t\t\t\t\t\t";
$m = 1;
$output = shell_exec("ls /var/www/html/p/backup ");
$backuplist = preg_split("/\r\n|\n|\r/", $output);
foreach ($backuplist as $backup) {
    if (!empty($backup)) {
        echo "<tr>\r\n\t\t\t\t\t\t\t\t\t\t\t<td class=\"text-center\">" . $m . "</td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td><span class=\"font-medium\">" . $backup . "</span></td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td></td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td></td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td></td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td></td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td><a href=\"restore.php?file=" . $backup . "\"><span class=\"label label-warning\">Restore</span></a></td>\r\n\t\t\t\t\t\t\t\t\t\t</tr>";
    }
    $m++;
}
echo "\t\t\t\t\t\t  </tbody>\r\n                            </table>\r\n\t\t\t\t\t\t</div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n\t\t\t</div>\r\n";
include "footer.php";

?>