<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

include "config.php";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    exit("Connection failed: " . $conn->connect_error);
}
$createtablesetting = "CREATE TABLE if not exists setting (\r\nid ENUM('1') NOT NULL ,\r\nadminuser VARCHAR(30),\r\n adminpassword VARCHAR(30) ,\r\n sshport VARCHAR(30) ,\r\n tgtoken VARCHAR(100) ,\r\n tgid VARCHAR(30) ,\r\n language VARCHAR(30) ,\r\n UNIQUE (id));";
if ($conn->query($createtablesetting) === true) {
    echo "Table Setting created <BR>";
}
$createuserlist = "CREATE TABLE if not exists `users` ( \r\n`id` bigint(20) NOT NULL AUTO_INCREMENT ,\r\n username VARCHAR(100),\r\n password VARCHAR(100) ,\r\n email VARCHAR(100) ,\r\n mobile VARCHAR(100) ,\r\n multiuser VARCHAR(100),\r\n startdate VARCHAR(100),\r\n finishdate VARCHAR(100),\r\n enable VARCHAR(30),\r\n traffic VARCHAR(100),\r\n referral VARCHAR(100),\r\n info VARCHAR(100),\r\n CONSTRAINT reference_unique UNIQUE (username) ,\r\n primary key (id));";
if ($conn->query($createuserlist) === true) {
    echo "Table Users created <br>";
}
$createtablesetting = "CREATE TABLE if not exists `servers` (\r\n`id` bigint(20) NOT NULL AUTO_INCREMENT ,\r\nserverip VARCHAR(100) NOT NULL,\r\nserverlocation VARCHAR(100) NOT NULL,\r\nserverusername VARCHAR(100) NOT NULL,\r\nserverpassword VARCHAR(100) NOT NULL,\r\n primary key (id));";
if ($conn->query($createtablesetting) === true) {
    echo "Table servers created <BR>";
}
$createtablesetting = "CREATE TABLE if not exists `tgmessage` (\r\nid ENUM('1') NOT NULL ,\r\naccount1m VARCHAR(900) ,\r\naccount2m VARCHAR(900) ,\r\naccount3m VARCHAR(900) ,\r\naccount6m VARCHAR(900) ,\r\naccount12m VARCHAR(900) ,\r\ncontactadmin VARCHAR(900) ,\r\nrahnama VARCHAR(900) ,\r\ntamdid VARCHAR(900) ,\r\n UNIQUE (id));";
if ($conn->query($createtablesetting) === true) {
    echo "Table tgmessage created <BR>";
}
$createtablesetting = "CREATE TABLE if not exists `ApiToken` (\r\n    `id` bigint(20) NOT NULL AUTO_INCREMENT ,\r\n    Token VARCHAR(100) NOT NULL,\r\n    Description VARCHAR(100) NOT NULL,\r\n    Allowips VARCHAR(100) NOT NULL,\r\n    enable VARCHAR(100) NOT NULL,\r\n     primary key (id));";
if ($conn->query($createtablesetting) === true) {
    echo "Table servers created <BR>";
}
$createtablesetting = "CREATE TABLE if not exists `Traffic` (\r\n    user VARCHAR(100) NOT NULL,\r\n    download VARCHAR(100) NOT NULL,\r\n    upload VARCHAR(100) NOT NULL,\r\n\ttotal VARCHAR(100) NOT NULL,\r\n\tCONSTRAINT reference_unique UNIQUE (user) ,\r\n    primary key (user));";
if ($conn->query($createtablesetting) === true) {
    echo "Table servers created <BR>";
}
$adduser = "ALTER TABLE Traffic ADD COLUMN total VARCHAR(100) AFTER upload;";
if ($conn->query($adduser) === true) {
}
$adduser = "ALTER TABLE users ADD COLUMN info VARCHAR(100) AFTER referral;";
if ($conn->query($adduser) === true) {
}
$adduser = "ALTER TABLE users ADD COLUMN days VARCHAR(100) AFTER info;";
if ($conn->query($adduser) === true) {
}
$adduser = "ALTER TABLE setting ADD COLUMN permissions VARCHAR(300) AFTER language;";
if ($conn->query($adduser) === true) {
}
$adduser = "ALTER TABLE setting ADD COLUMN credit VARCHAR(300) AFTER permissions;";
if ($conn->query($adduser) === true) {
}
$adduser = "ALTER TABLE setting MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;";
if ($conn->query($adduser) === true) {
}
$adduser = "ALTER TABLE setting ADD PRIMARY KEY (adminuser);";
if ($conn->query($adduser) === true) {
}
$sql = "delete FROM Traffic where user like '%[priv]%'; ";
if ($conn->query($sql) === true) {
}
$sql = "delete FROM Traffic where user like '%[accepted]%'; ";
if ($conn->query($sql) === true) {
}
$sql = "delete FROM Traffic where user like '%[rexeced]%'; ";
if ($conn->query($sql) === true) {
}
$sql = "delete FROM Traffic where user like '%[net]%'; ";
if ($conn->query($sql) === true) {
}
$sql = "delete FROM Traffic where user like '%@pts/1%'; ";
if ($conn->query($sql) === true) {
}
$sql = "delete FROM Traffic where user like '%sshd:%'; ";
if ($conn->query($sql) === true) {
}
$sql = "delete FROM Traffic where user like '%sbin/sshd%'; ";
if ($conn->query($sql) === true) {
}
$sql = "delete FROM Traffic where user like '%root:sshd%'; ";
if ($conn->query($sql) === true) {
}
$sql = "delete FROM Traffic where user like '%@notty%'; ";
if ($conn->query($sql) === true) {
}
$sql = "delete FROM Traffic where user like '% %'; ";
if ($conn->query($sql) === true) {
}
$adduser = "INSERT INTO tgmessage (account1m,account2m,account3m,account6m,account12m,contactadmin,rahnama,tamdid ) VALUES ('','','','','','','','');";
if ($conn->query($adduser) === true) {
    echo "tgmessage insted <br>";
}
$setting = "INSERT INTO setting (adminuser,adminpassword,sshport ) VALUES ( '" . $username . "', '" . $password . "', '" . $port . "');";
if ($conn->query($setting) === true) {
    echo "Setting Added <br>";
}
$output = shell_exec("cat /var/www/html/p/tarikh");
$userlist = preg_split("/\r\n|\n|\r/", $output);
foreach ($userlist as $user) {
    $userarray = explode(":", $user);
    $expdate = date("Y-m-d", strtotime($userarray[2] . " + " . $userarray[3] . " month"));
    if (!empty($userarray[0])) {
        $adduser = "INSERT INTO `users` (\r\n `username`,\r\n `password`,\r\n `email`,\r\n `mobile`,\r\n `multiuser` ,\r\n `startdate`,\r\n `finishdate`,\r\n `enable`,\r\n `traffic`,\r\n `referral` ) VALUES (\r\n '" . $userarray[0] . "',\r\n '" . $userarray[1] . "',\r\n '',\r\n '',\r\n '0',\r\n '" . $userarray[2] . "',\r\n '" . $expdate . "',\r\n 'true',\r\n '0',\r\n '');";
        if ($conn->query($adduser) === true) {
            echo $userarray[0] . " Added <br>";
        }
    }
}
$conn->close();

?>