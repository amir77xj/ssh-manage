<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

session_start();
include "config.php";
if (isset($_POST["loginsubmit"])) {
    $sql = "SELECT * FROM setting where adminuser='" . $_POST["username"] . "' and adminpassword='" . $_POST["password"] . "'";
    if ($result = mysqli_query($conn, $sql)) {
        $usercount = mysqli_num_rows($result);
    }
    if (0 < $usercount) {
        $_SESSION["username"] = $_POST["username"];
        $_SESSION["success"] = "شما وارد شدید";
        header("location: index.php");
    } else {
        echo "<div id=\"alerttopleft\" class=\"myadmin-alert myadmin-alert-img alert-info myadmin-alert-top-left\" style=\"display: block;\">\r\n<b>نام کاربری یا کلمه عبور اشتباه است</b></div>";
    }
}

?>