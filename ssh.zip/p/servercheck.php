<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

include "header.php";
include "menu.php";
$start_time = microtime(true);
$operating_system = PHP_OS_FAMILY;
$load = sys_getloadavg();
$cpuload = $load[0];
$free = shell_exec("free");
$free = (string) trim($free);
$free_arr = explode("\n", $free);
$mem = explode(" ", $free_arr[1]);
$mem = array_filter($mem, function ($value) {
    return $value !== NULL && $value !== false && $value !== "";
});
$mem = array_merge($mem);
$memtotal = round($mem[1] / 1000000, 2);
$memused = round($mem[2] / 1000000, 2);
$memfree = round($mem[3] / 1000000, 2);
$memshared = round($mem[4] / 1000000, 2);
$memcached = round($mem[5] / 1000000, 2);
$memavailable = round($mem[6] / 1000000, 2);
$connections = shell_exec("netstat -ntu | grep :80 | grep ESTABLISHED | grep -v LISTEN | awk '{print \$5}' | cut -d: -f1 | sort | uniq -c | sort -rn | grep -v 127.0.0.1 | wc -l");
$totalconnections = shell_exec("netstat -ntu | grep :80 | grep -v LISTEN | awk '{print \$5}' | cut -d: -f1 | sort | uniq -c | sort -rn | grep -v 127.0.0.1 | wc -l");
$memusage = round($memavailable / $memtotal * 100);
$phpload = round(memory_get_usage() / 1000000, 2);
$diskfree = round(disk_free_space(".") / 1000000000);
$disktotal = round(disk_total_space(".") / 1000000000);
$diskused = round($disktotal - $diskfree);
$diskusage = round($diskused / $disktotal * 100);
if (85 < $memusage || 85 < $cpuload || 85 < $diskusage) {
    $trafficlight = "red";
} else {
    if (50 < $memusage || 50 < $cpuload || 50 < $diskusage) {
        $trafficlight = "orange";
    } else {
        $trafficlight = "#2F2";
    }
}
$end_time = microtime(true);
$time_taken = $end_time - $start_time;
$total_time = round($time_taken, 4);
echo "\r\n <div class=\"row\">\r\n                <div class=\"col-md-12\">\r\n                    <div class=\"panel\">\r\n                        <div class=\"panel-heading\" style=\"display: inline-block;\">اطلاعات سرور : </div>\r\n\t\t\t\t\t\t<div class=\"table-responsive\" >\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t\t<div style=\"direction:ltr;padding-left:30px\">\r\n\t\t\t\t\t\t\r\n\t\t\r\n\t\t<p><span class=\"description\">🌡️ RAM Total:</span> <span class=\"result\">";
echo $memtotal;
echo " GB</span></p>\r\n\t\t<p><span class=\"description\">🌡️ RAM Used:</span> <span class=\"result\">";
echo $memused;
echo " GB</span></p>\r\n\t\t<p><span class=\"description\">🌡️ RAM Available:</span> <span class=\"result\">";
echo $memavailable;
echo " GB</span></p>\r\n\t\t<hr>\r\n\t\t<p><span class=\"description\">💽 Hard Disk Free:</span> <span class=\"result\">";
echo $diskfree;
echo " GB</span></p>\r\n\t\t<p><span class=\"description\">💽 Hard Disk Used:</span> <span class=\"result\">";
echo $diskused;
echo " GB</span></p>\r\n\t\t<p><span class=\"description\">💽 Hard Disk Total:</span> <span class=\"result\">";
echo $disktotal;
echo " GB</span></p>\r\n\t\t<hr>\r\n\t\t<div id=\"details\">\r\n\t\t\t<p><span class=\"description\">📟 Server Name: </span> <span class=\"result\">";
echo $_SERVER["SERVER_NAME"];
echo "</span></p>\r\n\t\t\t<p><span class=\"description\">💻 Server Addr: </span> <span class=\"result\">";
echo $_SERVER["SERVER_ADDR"];
echo "</span></p>\r\n\t\t\t<p><span class=\"description\">🌀 PHP Version: </span> <span class=\"result\">";
echo phpversion();
echo "</span></p>\r\n\t\t\t<p><span class=\"description\">🏋️ PHP Load: </span> <span class=\"result\">";
echo $phpload;
echo " GB</span></p>\r\n\t\t\t<p><span class=\"description\">⏱️ Load Time: </span> <span class=\"result\">";
echo $total_time;
echo " sec</span></p>\r\n\t\t</div>\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t\t\r\n                        \r\n\t\t\t\t\t\t</div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n\t\t\t</div>\r\n            ";
include "footer.php";
echo "\r\n\r\n\r\n\r\n\t\t\r\n\t";

?>