<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

include "header.php";
include "menu.php";
if (strpos($permission, "setting") !== false) {
    global $active;
    global $msg;
    $serverip = $_SERVER["SERVER_NAME"];
    $strSQL = "SELECT * FROM setting";
    $rs = mysqli_query($conn, $strSQL);
    while ($row = mysqli_fetch_array($rs)) {
        $TGToken = $row["tgtoken"];
        $TGID = $row["tgid"];
    }
    $strSQL = "SELECT * FROM tgmessage";
    $rs = mysqli_query($conn, $strSQL);
    while ($row = mysqli_fetch_array($rs)) {
        $msg1 = $row["account1m"];
        $msg2 = $row["account2m"];
        $msg3 = $row["account3m"];
        $msg4 = $row["account6m"];
        $msg5 = $row["account12m"];
        $msg6 = $row["contactadmin"];
        $msg7 = $row["rahnama"];
        $msg8 = $row["tamdid"];
    }
    if (!empty($_POST["giftuser"])) {
        $strSQL = "SELECT * FROM users";
        $rs = mysqli_query($conn, $strSQL);
        while ($row = mysqli_fetch_array($rs)) {
            $expdate = date("Y-m-d", strtotime($row["finishdate"] . " + " . $_POST["giftday"] . " day"));
            $sql = "UPDATE users SET finishdate='" . $expdate . "' where username='" . $row["username"] . "'";
            if ($conn->query($sql) === true) {
            }
        }
        $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nهدیه کاربران اضافه شد .\r\n</div>";
    }
    if (!empty($_POST["changetelegrammessages"])) {
        $sql = "UPDATE tgmessage SET account1m='" . $_POST["account1m"] . "',account2m='" . $_POST["account2m"] . "',account3m='" . $_POST["account3m"] . "',account6m='" . $_POST["account6m"] . "',account12m='" . $_POST["account12m"] . "',contactadmin='" . $_POST["contactadmin"] . "',rahnama='" . $_POST["rahnama"] . "',tamdid='" . $_POST["tamdid"] . "'";
        if ($conn->query($sql) === true) {
        }
        $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nپیام های ربات تلگرام ذخیره شد . \r\n</div>";
    }
    if (!empty($_POST["changetgsetting"])) {
        $sql = "ALTER TABLE `setting` MODIFY `tgtoken` LONGTEXT;";
        if ($conn->query($sql) === true) {
        }
        $sql = "UPDATE setting SET tgtoken='" . $_POST["TGToken"] . "'";
        if ($conn->query($sql) === true) {
        }
        $sql = "UPDATE setting SET tgid='" . $_POST["TGID"] . "'";
        if ($conn->query($sql) === true) {
        }
        $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nتغییرات تلگرام انجام شد .\r\n</div>";
        if (!empty($TGToken) && !empty($TGID)) {
            file_get_contents("https://api.telegram.org/bot" . $TGToken . "/setWebhook?url=https://" . $serverip . "/tgbot.php");
        }
    }
    if (!empty($_POST["changepassword"])) {
        if (!empty($_POST["password"])) {
            $sql = "SET PASSWORD FOR '" . $username . "'@'localhost' = PASSWORD('" . $_POST["password"] . "');";
            if ($conn->query($sql) === true) {
            }
            $sql = "FLUSH PRIVILEGES;";
            if ($conn->query($sql) === true) {
            }
            $sql = "GRANT ALL ON *.* TO '" . $username . "'@'localhost';";
            if ($conn->query($sql) === true) {
            }
            $sql = "UPDATE setting SET adminpassword='" . $_POST["password"] . "'";
            if ($conn->query($sql) === true) {
            }
            file_put_contents("/var/www/html/p/config.php", str_replace("\$password = \"" . $password, "\$password = \"" . $_POST["password"], file_get_contents("/var/www/html/p/config.php")));
            $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nرمز با موفقیت تغییر یافت.\r\n</div>";
        } else {
            $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nرمزعبور نمیتواند خالی باشد .\r\n</div>";
        }
    }
    if (!empty($_POST["changeport"])) {
        if (!empty($_POST["port"])) {
            $out = shell_exec("sudo sed -i 's@Port " . $port . "@Port " . $_POST["port"] . "@g' /etc/ssh/sshd_config");
            $out = shell_exec("sudo reboot");
            $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nپورت با موفقیت تغییر یافت. لطفا تا ریستارت شدن سرور صبر نمایید . ( تقریبا 2 دقیقه )\r\n</div>";
            $sql = "UPDATE setting SET sshport='" . $_POST["port"] . "'";
            if ($conn->query($sql) === true) {
            }
            $file_contents = file_get_contents("config.php");
            $file_contents = str_replace($port, $_POST["port"], $file_contents);
            file_put_contents("config.php", $file_contents);
        } else {
            $msg = "<div class=\"alert alert-danger alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nپورت نمیتواند خالی باشد .\r\n</div>";
        }
    }
    if (!empty($_POST["limitusers"])) {
        $limit = shell_exec("(crontab -l ; echo \"* * * * * bash /var/www/html/p/killusers.sh >/dev/null 2>&1\") | crontab -");
        $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nمحدودیت کاربر فعال شد . \r\n</div>";
        $active = "فعال";
    }
    if (!empty($_POST["notlimitusers"])) {
        $notlimit = shell_exec("crontab -l | grep -v '/var/www/html/p/killusers.sh'  | crontab  -");
        $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nمحدودیت کاربر غیرفعال شد . لطفا به مدت 1 دقیقه صبر کنید تا به صورت کامل غیرفعال شود . \r\n</div>";
        $active = "غیرفعال";
    }
    $limitactive = shell_exec("crontab -l");
    if (strpos($limitactive, "/var/www/html/p/killusers.sh") !== false) {
        $active = "فعال";
    } else {
        $active = "غیرفعال";
    }
    $date = date("Y-m-d-his");
    if (!empty($_GET["backupuser"])) {
        $output = shell_exec("mysqldump -u '" . $username . "' --password='" . $password . "' ShaHaN users > /var/www/html/p/backup/" . $date . "-users.sql");
        $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nبکاپ با موفقیت انجام شد \r\n</div>";
    }
    if (!empty($_GET["backupsetting"])) {
        $output = shell_exec("mysqldump -u '" . $username . "' --password='" . $password . "' ShaHaN setting > /var/www/html/p/backup/" . $date . "-setting.sql");
        $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nبکاپ با موفقیت انجام شد \r\n</div>";
    }
    if (!empty($_GET["backuptraffic"])) {
        $output = shell_exec("mysqldump -u '" . $username . "' --password='" . $password . "' ShaHaN traffic > /var/www/html/p/backup/" . $date . "-traffic.sql");
        $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nبکاپ با موفقیت انجام شد \r\n</div>";
    }
    if (!empty($_GET["backupfull"])) {
        $output = shell_exec("mysqldump -u '" . $username . "' --password='" . $password . "' ShaHaN > /var/www/html/p/backup/" . $date . "-full.sql");
        $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nبکاپ با موفقیت انجام شد \r\n</div>";
    }
    if (!empty($_GET["delete"])) {
        $output = shell_exec("rm -fr /var/www/html/p/backup/" . $_GET["delete"]);
        $msg = "<div class=\"alert alert-danger alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nفایل حذف شد \r\n</div>";
    }
    if (!empty($_POST["uploadsql"])) {
        $target_file = "backup/" . basename($_FILES["fileToUpload"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        if ($imageFileType != "sql") {
            $msg = "<div class=\"alert alert-danger alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nفقط فایل های SQL پشتیبانی میشود .\r\n</div>";
            $uploadOk = 0;
        }
        if ($uploadOk != 0) {
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nفایل با موفقیت آپلود شد .\r\n</div>";
            } else {
                $msg = "<div class=\"alert alert-danger alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nخطای آپلود .\r\n</div>";
            }
        }
    }
    if (!empty($_GET["file"])) {
        if (strpos($_GET["file"], ".sql") !== false) {
            $output = shell_exec("mysql -u '" . $username . "' --password='" . $password . "' ShaHaN < /var/www/html/p/backup/" . $_GET["file"]);
            $sql = "SELECT * FROM users where enable='true'";
            $rs = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_array($rs)) {
                $out = shell_exec("bash adduser " . $row["username"] . " " . $row["password"]);
                $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nبازگردانی کاربران با موفقیت انجام شد\r\n</div>";
            }
        } else {
            $msg = "<div class=\"alert alert-danger alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nفقط فایل های SQL پشتیبانی میشود .\r\n</div>";
        }
    }
    if (!empty($_POST["createtoken"])) {
        $nettoken = gen_token();
        $addtoken = "INSERT INTO ApiToken (enable,Token,Description,Allowips) VALUES ('true','" . $nettoken . "','" . $_POST["Description"] . "','" . $_POST["Allowips"] . "');";
        if ($conn->query($addtoken) === true) {
            $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n\t   <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\n\t\t\tتوکن اضافه شد\r\n\t   </div>";
        }
    }
    if (!empty($_GET["remove_token"])) {
        $sql = "delete FROM ApiToken where Token='" . $_GET["remove_token"] . "'";
        if ($conn->query($sql) === true) {
        }
        $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n\t<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\n\tتوکن با موفقیت حذف شد\r\n\t</div>";
    }
    if (!empty($_GET["revoke_token"])) {
        $nettoken = gen_token();
        $sql = "UPDATE ApiToken SET Token='" . $nettoken . "'WHERE Token='" . $_GET["revoke_token"] . "'";
        if ($conn->query($sql) === true) {
        }
        $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n   <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\n   توکن جدید " . $nettoken . "\r\n   </div>";
    }
    if (!empty($_POST["blockiran"])) {
        $linecount = 0;
        $matn = "#!/bin/bash \n";
        for ($iplist = fopen("iran-ip.txt", "r"); $line = fgets($iplist); $linecount++) {
            $line = preg_replace("/\\s+/", "", $line);
            $matn = $matn . "sudo iptables -A OUTPUT -d " . $line . " -j DROP \n";
        }
        fclose($iplist);
        file_put_contents("iptables/rule.sh", $matn);
        $notlimit = shell_exec("bash iptables/rule.sh");
        $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nتعداد " . $linecount . " آی پی بلاک شد . \r\n</div>";
    }
    if (!empty($_POST["freeiran"])) {
        $notlimit = shell_exec("sudo iptables -F");
        $msg = "<div class=\"alert alert-success alert-dismissable\">\r\n<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>\r\nمحدودیت ای پی غیر فعال شد\r\n</div>";
    }
    $limitlist = shell_exec("sudo iptables -L OUTPUT");
    $limitlist = preg_split("/\r\n|\n|\r/", $limitlist);
    $iptablesnumber = count($limitlist) - 3;
    if (0 < $iptablesnumber) {
        $blockactive = "فعال - تعداد آی پی بلاک شده : " . $iptablesnumber;
    } else {
        $blockactive = "غیرفعال";
    }
    echo "            <div class=\"row\">\r\n                <div class=\"col-md-12\">\r\n                    <div class=\"panel\">\r\n                        <div class=\"panel-heading\" style=\"display: inline-block;\">تنظیمات</div>\r\n\t\t\t\t\t\t";
    echo $msg;
    echo "\t\t\t\t\t\t<div class=\"table-responsive\" style=\"padding: 20px;\">\r\n\t\t\t\t\t\t\t<ul class=\"nav nav-tabs\" role=\"tablist\">\r\n                                <li role=\"presentation\" class=\"active\"><a href=\"#Tab1\" aria-controls=\"Tab1\" role=\"tab\" data-toggle=\"tab\" aria-expanded=\"true\"><span class=\"visible-xs\"><i class=\"ti-home\"></i></span><span class=\"hidden-xs\">رمز عبور</span></a></li>\r\n                                <li role=\"presentation\" class=\"\"><a href=\"#Tab2\" aria-controls=\"Tab2\" role=\"tab\" data-toggle=\"tab\" aria-expanded=\"false\"><span class=\"visible-xs\"><i class=\"ti-user\"></i></span> <span class=\"hidden-xs\">پورت SSH</span></a></li>\r\n\t\t\t\t\t\t\t\t<li role=\"presentation\" class=\"\"><a href=\"#Tab3\" aria-controls=\"Tab3\" role=\"tab\" data-toggle=\"tab\" aria-expanded=\"false\"><span class=\"visible-xs\"><i class=\"ti-user\"></i></span> <span class=\"hidden-xs\">محدودیت کاربر</span></a></li>\r\n\t\t\t\t\t\t\t\t<li role=\"presentation\" class=\"\"><a href=\"#Tab4\" aria-controls=\"Tab4\" role=\"tab\" data-toggle=\"tab\" aria-expanded=\"false\"><span class=\"visible-xs\"><i class=\"ti-user\"></i></span> <span class=\"hidden-xs\">ربات تلگرام</span></a></li>\r\n                            \t<li role=\"presentation\" class=\"\"><a href=\"#Tab6\" aria-controls=\"Tab6\" role=\"tab\" data-toggle=\"tab\" aria-expanded=\"false\"><span class=\"visible-xs\"><i class=\"ti-user\"></i></span> <span class=\"hidden-xs\">بکاپ و ریستور</span></a></li>\r\n\t\t\t\t\t\t\t\t<li role=\"presentation\" class=\"\"><a href=\"#Tab7\" aria-controls=\"Tab7\" role=\"tab\" data-toggle=\"tab\" aria-expanded=\"false\"><span class=\"visible-xs\"><i class=\"ti-user\"></i></span> <span class=\"hidden-xs\">توکن API</span></a></li>\r\n\t\t\t\t\t\t\t\t<li role=\"presentation\" class=\"\"><a href=\"#Tab8\" aria-controls=\"Tab8\" role=\"tab\" data-toggle=\"tab\" aria-expanded=\"false\"><span class=\"visible-xs\"><i class=\"ti-user\"></i></span> <span class=\"hidden-xs\">بلاک ای پی</span></a></li>\r\n\t\t\t\t\t\t\t\t<li role=\"presentation\" class=\"\"><a href=\"#Tab9\" aria-controls=\"Tab9\" role=\"tab\" data-toggle=\"tab\" aria-expanded=\"false\"><span class=\"visible-xs\"><i class=\"ti-user\"></i></span> <span class=\"hidden-xs\">هدیه روزانه</span></a></li>\r\n\t\t\t\t\t\t\t</ul>\r\n\t\t\t\t\t\t\t<div class=\"tab-content\">\r\n                                <div role=\"tabpanel\" class=\"tab-pane active\" id=\"Tab1\">\r\n                                    <div class=\"col-md-6\">\r\n                                        <h3>تغییر رمز عبور مدیر : </h3>\r\n\t\t\t\t\t\t\t\t\t\t<form action=\"setting.php\" method=\"post\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputEmail1\">نام کاربری : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"username\" type=\"text\" class=\"form-control\" id=\"exampleInputEmail1\" placeholder=\"";
    echo $username;
    echo "\" disabled>\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">رمز جدید : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"password\" type=\"text\" class=\"form-control\" id=\"exampleInputPassword1\" placeholder=\"Password\">\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<button name=\"changepassword\" type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\" value=\"changepassword\" >ثبت</button>\r\n\t\t\t\t\t\t\t\t\t\t</form>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n                                    <div class=\"clearfix\"></div>\r\n                                </div>\r\n                                <div role=\"tabpanel\" class=\"tab-pane\" id=\"Tab2\">\r\n                                    <div class=\"col-md-6\">\r\n                                        <h3>تغییر پورت SSH : </h3>\r\n\t\t\t\t\t\t\t\t\t\t<form action=\"setting.php\" method=\"post\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">پورت جدید : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"port\" type=\"number\" class=\"form-control\" id=\"exampleInputPassword1\" placeholder=\"";
    echo $port;
    echo "\">\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<button name=\"changeport\" type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\" value=\"changeport\" >ثبت</button>\r\n\t\t\t\t\t\t\t\t\t\t</form>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n                                    <div class=\"clearfix\"></div>\r\n                                </div>\r\n\t\t\t\t\t\t\t\t<div role=\"tabpanel\" class=\"tab-pane\" id=\"Tab3\">\r\n                                    <div class=\"col-md-6\">\r\n                                        <h3>محدودیت استفاده کاربران : </h3>\r\n\t\t\t\t\t\t\t\t\t\t<form action=\"setting.php\" method=\"post\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">وضعیت محدودیت : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"port\" type=\"number\" class=\"form-control\" id=\"exampleInputPassword1\" placeholder=\"";
    echo $active;
    echo "\" disabled>\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<button name=\"limitusers\" type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\" value=\"changeport\" >فعال کردن</button>\r\n\t\t\t\t\t\t\t\t\t\t\t<button name=\"notlimitusers\" type=\"submit\" class=\"btn btn-danger waves-effect waves-light m-r-10\" value=\"changeport\" >غیرفعال کردن</button>\r\n\t\t\t\t\t\t\t\t\t\t</form>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n                                    <div class=\"clearfix\"></div>\r\n                                </div>\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t<div role=\"tabpanel\" class=\"tab-pane\" id=\"Tab4\">\r\n                                    <div class=\"col-md-6\">\r\n                                        <h3>تنظیمات ربات تلگرام : </h3>\r\n\t\t\t\t\t\t\t\t\t\t<p>مرحله اول : یک دامنه تهیه کرده و از طریق دستور گیت هاب SSL ثبت کنین .</p>\r\n\t\t\t\t\t\t\t\t\t\t<p><a href=\"https://github.com/HamedAp/Ssh-User-management\">لینک گیت هاب برای تهیه SSL </a></p>\r\n\t\t\t\t\t\t\t\t\t\t<p>مرحله دوم : با دامنه وارد پنل شوید و در قسمت تنظیمات توکن تلگرام و آی دی مدیر را وارد کنید </p>\r\n\t\t\t\t\t\t\t\t\t\t<p>در صورتی که با توکن و آی دی تلگرام مدیر آشنایی ندارید در گروه تلگرامی سوال فرمایید . </p>\r\n\t\t\t\t\t\t\t\t\t\t<p>بعد از ثبت کردن توکن و ای دی به ربات خود پیام /start را داده و لذت ببرید . </p>\r\n\t\t\t\t\t\t\t\t\t\t<p>دونیت برای سازنده یادتون نره :) </p>\r\n\t\t\t\t\t\t\t\t\t\t<hr>\r\n\t\t\t\t\t\t\t\t\t\t<form action=\"setting.php\" method=\"post\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">توکن ربات تلگرام : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"TGToken\" type=\"text\" class=\"form-control\" id=\"exampleInputPassword1\" value=\"";
    echo $TGToken;
    echo "\" style=\"direction: ltr;\">\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">آی دی مدیر : ( به صورت عددی )</label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"TGID\" type=\"text\" class=\"form-control\" id=\"exampleInputPassword1\" value=\"";
    echo $TGID;
    echo "\" style=\"direction: ltr;\">\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<button name=\"changetgsetting\" type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\" value=\"changetg\" >ثبت</button>\r\n\t\t\t\t\t\t\t\t\t\t</form>\r\n\t\t\t\t\t\t\t\t\t\t<hr>\r\n\t\t\t\t\t\t\t\t\t\t<form action=\"setting.php\" method=\"post\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-12\">توضیحات اکانت یک ماهه : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-12\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t<textarea class=\"form-control\" rows=\"5\" name=\"account1m\">";
    echo $msg1;
    echo "</textarea>\r\n\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-12\">توضیحات اکانت دو ماهه : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-12\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t<textarea class=\"form-control\" rows=\"5\" name=\"account2m\">";
    echo $msg2;
    echo "</textarea>\r\n\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-12\">توضیحات اکانت سه ماهه : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-12\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t<textarea class=\"form-control\" rows=\"5\" name=\"account3m\">";
    echo $msg3;
    echo "</textarea>\r\n\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-12\">توضیحات اکانت شش ماهه : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-12\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t<textarea class=\"form-control\" rows=\"5\" name=\"account6m\">";
    echo $msg4;
    echo "</textarea>\r\n\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-12\">توضیحات اکانت یکساله</label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-12\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t<textarea class=\"form-control\" rows=\"5\" name=\"account12m\">";
    echo $msg5;
    echo "</textarea>\r\n\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-12\">تماس با مدیر : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-12\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t<textarea class=\"form-control\" rows=\"5\" name=\"contactadmin\">";
    echo $msg6;
    echo "</textarea>\r\n\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-12\">راهنما : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-12\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t<textarea class=\"form-control\" rows=\"5\" name=\"rahnama\">";
    echo $msg7;
    echo "</textarea>\r\n\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"col-md-12\">تمدید اکانت : </label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-12\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t<textarea class=\"form-control\" rows=\"5\" name=\"tamdid\">";
    echo $msg8;
    echo "</textarea>\r\n\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<button name=\"changetelegrammessages\" type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\" value=\"changetelegrammessages\" >ثبت</button>\r\n\t\t\t\t\t\t\t\t\t\t</form>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n                                    <div class=\"clearfix\"></div>\r\n                                </div>\r\n\t\t\t\t\t\t\t\t<div role=\"tabpanel\" class=\"tab-pane\" id=\"Tab6\">\r\n                                    <div class=\"col-md-6\">\r\n\t\t\t\t\t\t\t\t\t<h3>بکاپ و ریستور</h3>\r\n\t\t\t\t\t\t\t\t\t\t<a href=\"setting.php?backupfull=";
    echo $date;
    echo "\" class=\"btn btn-primary m-t-10 btn-rounded\" style=\"margin-right: 40px !important;\">بکاپ کلی</a>\r\n\t\t\t\t\t\t\t\t\t\t<a href=\"setting.php?backupuser=";
    echo $date;
    echo "\" class=\"btn btn-primary m-t-10 btn-rounded\" style=\"margin-right: 40px !important;\">بکاپ کاربران</a>\r\n\t\t\t\t\t\t\t\t\t\t<a href=\"setting.php?backuptraffic=";
    echo $date;
    echo "\" class=\"btn btn-primary m-t-10 btn-rounded\" style=\"margin-right: 40px !important;\">بکاپ ترافیک</a>\r\n\t\t\t\t\t\t\t\t\t\t<a href=\"setting.php?backupsetting=";
    echo $date;
    echo "\" class=\"btn btn-primary m-t-10 btn-rounded\" style=\"margin-right: 40px !important;\">بکاپ تنظیمات</a>\r\n\t\t\t\t\t\t\t\t\t\t</br></br><hr>\r\n\t\t\t\t\t\t\t\t\t\t<form action=\"setting.php\" method=\"post\" style=\"display:block;\" enctype=\"multipart/form-data\">\r\n\t\t\t\t\t\t<input type=\"file\" name=\"fileToUpload\" id=\"fileToUpload\" style=\"float: right !important;margin-left: 20px!important;display: inline !important;margin-right: 50px;\">\r\n\t\t\t\t\t\t<button name=\"uploadsql\" type=\"submit\" class=\"btn-rounded btn btn-primary pull-right waves-effect waves-light\" value=\"upload\" style=\"float: right !important;margin-left: 40px!important;\" >آپلود بکاپ</button>\r\n\t\t\t\t\t\t</form>\r\n\t\t\t\t\t\t<table class=\"table table-hover manage-u-table\">\r\n                                <thead>\r\n\t\t\t\t\t\t\t\t\t<tr>\r\n                                        <th width=\"70\" class=\"text-center\">#</th>\r\n                                        <th>تاریخ بکاپ</th>\r\n                                        <th></th>\r\n                                        <th></th>\r\n                                        <th></th>\r\n                                        <th width=\"250\"></th>\r\n                                        <th width=\"300\">دریافت</th>\r\n                                    </tr>\r\n                                </thead>\r\n                                <tbody>\r\n\t\t\t\t\t\t\t\t";
    $m = 1;
    $output = shell_exec("ls /var/www/html/p/backup");
    $backuplist = preg_split("/\r\n|\n|\r/", $output);
    foreach ($backuplist as $backup) {
        if (!empty($backup)) {
            echo "\r\n\t\t\t\t\t\t\t\t\t\t<tr>\r\n\t\t\t\t\t\t\t\t\t\t\t<td class=\"text-center\">" . $m . "</td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td><span class=\"font-medium\">" . $backup . "</span></td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td></td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td></td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td></td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td></td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td><a href=\"/p/backup/" . $backup . "\"><span class=\"label label-success\">Download</span></a>\r\n\t\t\t\t\t\t\t\t\t\t\t<a href=\"setting.php?delete=" . $backup . "\"><span class=\"label label-danger\">Remove</span></a>\r\n\t\t\t\t\t\t\t\t\t\t\t<a href=\"setting.php?file=" . $backup . "\"><span class=\"label label-warning\">Restore</span></a></td>\r\n\t\t\t\t\t\t\t\t\t\t</tr>";
        }
        $m++;
    }
    echo "\t\t\t\t\t\t\t\t</tbody>\r\n                        </table>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n                                    <div class=\"clearfix\"></div>\r\n                                </div>\r\n\t\t\t\t\t\t\t\t<div role=\"tabpanel\" class=\"tab-pane\" id=\"Tab7\">\r\n                                    <div class=\"col-md-6\">\r\n\t\t\t\t\t\t\t\t\t<h3>توکن API</h3>\r\n\t\t\t\t\t\t\t\t\t<form action=\"setting.php\" method=\"post\">\r\n\t\t\t\t\t\t\t\t\t\t<h3>ساخت توکن جدید</h3>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputEmail1\">توضیحات توکن</label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"Description\" type=\"text\" class=\"form-control\" id=\"exampleInputEmail1\" >\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">آی پی های مجاز</label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"Allowips\" type=\"text\" class=\"form-control\" id=\"exampleInputPassword1\" placeholder=\"Password\" value=\"0.0.0.0/0\">\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<button name=\"createtoken\" type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\" value=\"createtoken\" >ثبت</button>\r\n\t\t\t\t\t\t\t\t\t\t</form>\r\n\t\t\t\t\t\t\t\t\t\t<hr>\r\n\t\t\t\t\t\t\t\t\t\t<h3>لیست توکن ها </h3>\r\n\t\t\t\t\t\t\t\t\t\t";
    $m = 1;
    $strSQL = "SELECT * FROM ApiToken";
    $rs = mysqli_query($conn, $strSQL);
    echo "<div class=\"table-responsive\" style=\"padding-bottom: 200px !important;overflow: inherit;\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<table class=\"table table-hover manage-u-table\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<thead>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th width=\"70\" class=\"text-center\">#</th>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th>Token</th>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th>توضیحات</th>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th>آی پی های مجاز</th>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th>نوسازی توکن</th>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th>غیر فعال کردن</th>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</thead>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tbody>";
    while ($row = mysqli_fetch_array($rs)) {
        echo "<tr>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"text-center\">" . $m . "</td>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<td>" . $row["Token"] . "</td>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<td>" . $row["Description"] . "</td>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<td>" . $row["Allowips"] . "</td>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<td><a href=\"setting.php?revoke_token=" . $row["Token"] . "\" ><i class=\"fa fa-refresh text-warning\" style=\"font-size:20px;\"></i></a></td>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<td><a href=\"setting.php?remove_token=" . $row["Token"] . "\" ><i class=\"fa fa-minus-circle text-danger\" style=\"font-size:20px;\"></i></a></td>";
        $m++;
    }
    echo "\t\t\t\t\t\t\t\t\t\t</tbody>\r\n\t\t\t\t\t\t\t\t\t\t</table>\r\n\t\t\t\t\t\t\t\t\t\t<hr>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n                                    <div class=\"clearfix\"></div>\r\n                                </div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div role=\"tabpanel\" class=\"tab-pane\" id=\"Tab8\">\r\n                                    <div class=\"col-md-6\">\r\n                                        <h3>بلاک کردن آی پی : </h3>\r\n\t\t\t\t\t\t\t\t\t\t<form action=\"setting.php\" method=\"post\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">بلاک آی پی های ایرانی</label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"port\" type=\"number\" class=\"form-control\" id=\"exampleInputPassword1\" placeholder=\"";
    echo $blockactive;
    echo "\" disabled>\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<button name=\"blockiran\" type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\" value=\"changeport\" >فعال کردن</button>\r\n\t\t\t\t\t\t\t\t\t\t\t<button name=\"freeiran\" type=\"submit\" class=\"btn btn-danger waves-effect waves-light m-r-10\" value=\"changeport\" >غیرفعال کردن</button>\r\n\t\t\t\t\t\t\t\t\t\t</form>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n                                    <div class=\"clearfix\"></div>\r\n                                </div>\t\r\n\t\t\t\t\t\t\t\t<div role=\"tabpanel\" class=\"tab-pane\" id=\"Tab9\">\r\n                                    <div class=\"col-md-6\">\r\n                                        <h3>هدیه روزانه : </h3>\r\n\t\t\t\t\t\t\t\t\t\t<form action=\"setting.php\" method=\"post\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<label for=\"exampleInputPassword1\">اضافه کردن تعداد روز به کل کاربران</label>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"giftday\" type=\"number\" class=\"form-control\" id=\"exampleInputPassword1\" >\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<button name=\"giftuser\" type=\"submit\" class=\"btn btn-success waves-effect waves-light m-r-10\" value=\"giftuser\" >ثبت</button>\r\n\t\t\t\t\t\t\t\t\t\t</form>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n                                    <div class=\"clearfix\"></div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n\t\t</div>\r\n";
    include "footer.php";
} else {
    exit;
}

?>