<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2 & 7.3
 * @ Decoder version: 1.0.6
 * @ Release: 10/08/2022
 */

include "header.php";
include "menu.php";
if ($_GET["username"]) {
    $sql = "delete FROM Traffic where user='" . $_GET["username"] . "'";
    if ($conn->query($sql) === true) {
    }
}
if (strpos($permission, "traffic") !== false) {
    $lastarray = [];
    $strSQL = "select * from Traffic ORDER BY CAST(total AS UNSIGNED) DESC, total ;";
    $rs = mysqli_query($conn, $strSQL);
    while ($row = mysqli_fetch_array($rs)) {
        $lastarray[] = $row;
    }
    echo "<div class=\"row\">\r\n                <div class=\"col-md-12\">\r\n                    <div class=\"panel\">\r\n                        <div class=\"panel-heading\" style=\"display: inline-block;\">لیست ترافیک مصرفی کاربران</div>\r\n\t\t\t\t\t\t<div class=\"table-responsive\">\r\n                            <table class=\"table table-hover manage-u-table\">\r\n                                <thead>\r\n\t\t\t\t\t\t\t\t <tr>\r\n                                        <th width=\"70\" class=\"text-center\">#</th>\r\n                                        <th>نام کاربری</th>\r\n                                        <th>دانلود</th>\r\n                                        <th>آپلود</th>\r\n                                        <th>جمع</th>\r\n\t\t\t\t\t\t\t\t\t\t<th>عملیات</th>\r\n                                 </tr>\r\n                                </thead>\r\n                                <tbody>\r\n\t\t\t\t\t\t\t\t";
    $m = 1;
    foreach ($lastarray as $user) {
        if (1024 < $user["download"]) {
            $dl = round($user["download"] / 1024, 2) . " گیگابایت";
        } else {
            $dl = $user["download"] . " مگابایت";
        }
        if (1024 < $user["upload"]) {
            $up = round($user["upload"] / 1024, 2) . " گیگابایت";
        } else {
            $up = $user["upload"] . " مگابایت";
        }
        if (1024 < $user["total"]) {
            $to = round($user["total"] / 1024, 2) . " گیگابایت";
        } else {
            $to = $user["total"] . " مگابایت";
        }
        echo "<tr>\r\n                                        <td class=\"text-center\">" . $m . "</td>\r\n                                        <td><span class=\"font-medium\">" . $user["user"] . "</span></td>\r\n                                        <td><span class=\"font-medium\">" . $dl . "</span></td>\r\n                                        <td><span class=\"font-medium\">" . $up . "</span></td>\r\n\t\t\t\t\t\t\t\t\t\t<td><span class=\"font-medium\">" . $to . "</span></td>\r\n\t\t\t\t\t\t\t\t\t\t<td><a href=\"traffic.php?username=" . $user["user"] . "\"><span class=\"label label-danger\">Delete</span></a></td>\r\n                                    </tr>";
        $m++;
    }
    echo "                                </tbody>\r\n                            </table>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n\t\t\t</div>\r\n            ";
    include "footer.php";
} else {
    exit;
}

?>